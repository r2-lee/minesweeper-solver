from __future__ import annotations

import argparse
from collections import Counter, defaultdict
import csv
import json
from pathlib import Path
from statistics import mean, median

from exact_oracle import read_states


def load_python(path):
    result = {}
    with path.open(encoding="utf-8-sig") as stream:
        for line in stream:
            row = json.loads(line)
            if row["status"] == "exact":
                result[row["id"]] = row
    return result


def load_engine_results(path):
    with path.open(encoding="utf-8-sig", newline="") as stream:
        return {record["id"]: record for record in csv.DictReader(stream, delimiter="\t")}


def action_columns(matrix):
    with matrix.open("rb") as stream:
        count, cells, hill, edlogg, safest = map(int, stream.readline().split())
        columns = [line.strip() for line in stream]
    assert len(columns) == cells and all(len(col) == count for col in columns)
    return count, columns, (hill, edlogg, safest)


def survival_set(column):
    return int.from_bytes(column.translate(bytes(0 if i == 77 else 1 for i in range(256))), "little")


def solve_cohort(states, matrices, python_runs, external_runs):
    sources = defaultdict(dict)
    reference = {}
    for path in python_runs:
        for key, row in load_python(path).items():
            reference[key] = row
    for path in external_runs:
        for key, row in load_engine_results(path).items():
            sources[key][path.stem] = row

    result = []
    for row in read_states(states):
        key = row["id"]
        count, columns, indices = action_columns(matrices / (key + ".txt"))
        assert count == int(row["layout_count"])
        hidden = [i for i, item in enumerate(row["state"]) if item == "H"]
        hi, ed, mi = indices
        masks = [survival_set(columns[i]) for i in indices]
        h, e, most = (mask.bit_count() for mask in masks)
        assert most == max(len(c) - c.count(b"M") for c in columns)
        assert hidden[hi] == int(row["hill_tile"])
        if masks[0] == masks[1]:
            relation = "equal"
        elif masks[0] & masks[1] == masks[1]:
            relation = "hill_superset"
        elif masks[0] & masks[1] == masks[0]:
            relation = "ed_superset"
        else:
            relation = "incomparable"

        candidates = {}
        if key in reference:
            values = reference[key]["tile_values"]
            assert [tile for tile, _, _ in values] == hidden
            candidates["python"] = (max(v[-1] for v in values), *(values[i][-1] for i in indices))
        for name, scores in sources[key].items():
            if scores["status"] == "exact":
                candidates[name] = (int(scores.get("v", scores.get("V"))), int(scores["hill"]),
                                    int(scores.get("edlogg", scores.get("ed"))), int(scores["safest"]))
        if len(set(candidates.values())) > 1:
            raise ValueError(f"{key} inconsistent exact results: {candidates}")

        record = {
            "id": key, "seed": int(row["seed"]), "layout_index": int(row["layout_index"]),
            "guess_ordinal": int(row["guess_ordinal"]), "layout_count": count,
            "whole_bf_status": row["whole_bf_status"], "hidden": len(hidden),
            "hill_tile": hidden[hi], "edlogg_tile": hidden[ed], "safest_tile": hidden[mi],
            "hill_survivors": h, "edlogg_survivors": e, "safest_survivors": most,
            "survival_relation": relation, "status": "exact" if candidates else "unresolved",
            "exact_sources": "+".join(candidates), "optimal_winners": None,
            "hill_winners": None, "edlogg_winners": None, "safest_winners": None,
            "optimal_tiles_python": "", "best_safest_winners_python": None,
            "alt_max_safety_count": sum(count - c.count(b"M") == most for c in columns)
        }
        if candidates:
            v, qh, qe, qm = next(iter(candidates.values()))
            assert 0 <= qh <= min(h, v) and 0 <= qe <= min(e, v) and 0 <= qm <= min(most, v)
            assert 1 <= v <= most <= count
            if relation == "equal":
                assert qh == qe
            if relation == "hill_superset":
                assert qh >= qe
            if relation == "ed_superset":
                assert qe >= qh
            record.update(optimal_winners=v, hill_winners=qh, edlogg_winners=qe, safest_winners=qm)
            if key in reference:
                values = reference[key]["tile_values"]
                record["optimal_tiles_python"] = ",".join(str(tile) for tile, _, q in values if q == v)
                record["best_safest_winners_python"] = max(q for _, s, q in values if s == most)
        result.append(record)
    return result


def metrics(result):
    return {
        "states": len(result),
        "hill_optimal": sum(row["hill_winners"] == row["optimal_winners"] for row in result),
        "edlogg_optimal": sum(row["edlogg_winners"] == row["optimal_winners"] for row in result),
        "safest_optimal": sum(row["safest_winners"] == row["optimal_winners"] for row in result),
        "ed_ahead": sum(row["edlogg_winners"] > row["hill_winners"] for row in result),
        "hill_ahead": sum(row["hill_winners"] > row["edlogg_winners"] for row in result),
        "oracle_average": mean(row["optimal_winners"] / row["layout_count"] for row in result),
        "hill_average": mean(row["hill_winners"] / row["layout_count"] for row in result),
        "edlogg_average": mean(row["edlogg_winners"] / row["layout_count"] for row in result),
        "safest_average": mean(row["safest_winners"] / row["layout_count"] for row in result),
        "oracle_above_both_pp": 100 * mean(
            (row["optimal_winners"] - max(row["hill_winners"], row["edlogg_winners"])) / row["layout_count"]
            for row in result),
        "both_below": sum(max(r["hill_winners"], r["edlogg_winners"]) < r["optimal_winners"] for r in result),
        "same_tile": sum(r["hill_tile"] == r["edlogg_tile"] for r in result),
        "both_below_same_tile": sum(r["hill_tile"] == r["edlogg_tile"]
                                   and r["hill_winners"] < r["optimal_winners"] for r in result),
        "both_below_at_least_1pp": sum(
            100 * (r["optimal_winners"] - max(r["hill_winners"], r["edlogg_winners"])) >= r["layout_count"]
            for r in result),
        "different_exact_trees": dict(Counter(r["exact_sources"] for r in result)),
        "median_layouts": median(r["layout_count"] for r in result),
    }


def summarize(result):
    exact = [r for r in result if r["status"] == "exact"]
    group = {
        "total": len(result),
        "all_survival_relations": Counter(r["survival_relation"] for r in result),
        "all_same_tile": sum(r["hill_tile"] == r["edlogg_tile"] for r in result),
        "all_posterior_median": median(r["layout_count"] for r in result),
        "exact": metrics(exact) if exact else None,
    }
    for seed in ("2026", "9127"):
        subset = [r for r in exact if r["seed"] == int(seed)]
        if subset:
            group[seed] = metrics(subset)
    for relation in ("equal", "incomparable", "hill_superset", "ed_superset"):
        subset = [r for r in exact if r["survival_relation"] == relation]
        if subset:
            group[relation] = metrics(subset)
    full_action = [r for r in exact if r["best_safest_winners_python"] is not None]
    if full_action:
        group["max_safety_all_actions"] = {
            "n": len(full_action),
            "optimal_requires_higher_risk": sum(r["best_safest_winners_python"] < r["optimal_winners"] for r in full_action),
            "safest_actions_value_varies": sum(r["best_safest_winners_python"] > r["safest_winners"] for r in full_action),
        }
    return group


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("states", type=Path)
    parser.add_argument("matrices", type=Path)
    parser.add_argument("per_state", type=Path)
    parser.add_argument("summary", type=Path)
    parser.add_argument("--python", nargs="*", type=Path, default=[])
    parser.add_argument("--external", nargs="*", type=Path, default=[])
    args = parser.parse_args()
    records = solve_cohort(args.states, args.matrices, args.python, args.external)
    with args.per_state.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(records[0]), delimiter="\t")
        writer.writeheader()
        writer.writerows(records)
    args.summary.write_text(json.dumps(summarize(records), indent=2) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
