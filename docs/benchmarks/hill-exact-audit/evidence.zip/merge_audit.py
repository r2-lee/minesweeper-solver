from __future__ import annotations

import argparse
from collections import Counter, defaultdict
import csv
import json
from pathlib import Path
from statistics import mean, median

from exact_oracle import read_states
from summarize_audit import action_columns, load_python, survival_set

NAMES = ("v", "hill", "edlogg", "safest")
ALIASES = {"v": "V", "edlogg": "ed"}
THRESHOLDS = (0.25, 0.5, 1.0, 2.0, 5.0)


def read_evidence(files):
    source = defaultdict(list)
    references = {}
    for path in files:
        if not path.is_file():
            raise FileNotFoundError(path)
        if path.suffix == ".jsonl":
            for key, solved in load_python(path).items():
                references[key] = solved
        else:
            with path.open(encoding="utf-8-sig", newline="") as file:
                for row in csv.DictReader(file, delimiter="\t"):
                    source[row["id"]].append((path.name, row))
    return source, references


def narrow(target, name, lower, upper):
    lo, hi = target[name]
    interval = max(lo, lower), min(hi, upper)
    if interval[0] > interval[1]:
        raise ValueError(f"{name} bounds {target[name]} conflict with {(lower, upper)}")
    target[name] = interval


def apply_result(bounds, row):
    fields = 0
    for key in NAMES:
        if row.get(key + "_lo") and row.get(key + "_hi"):
            lo, hi = int(row[key + "_lo"]), int(row[key + "_hi"])
            narrow(bounds, key, lo, hi)
            fields += lo == hi
        else:
            value = row.get(key) or row.get(ALIASES.get(key))
            if value and value != "NA":
                narrow(bounds, key, int(value), int(value))
                fields += 1
    return fields


def intersect_choices(bounds, masks, live_sets):
    choices = dict(zip(NAMES[1:], masks))
    max_bound = lambda m: min([m.bit_count(), *(bounds[k][1] for k, cover in choices.items() if m & cover == m)])
    while True:
        start = tuple(bounds.values())
        if live_sets:
            narrow(bounds, "v", max(bounds[name][0] for name in NAMES), max(map(max_bound, live_sets)))
        else:
            narrow(bounds, "v", 1, 1)
        for sub, smaller in choices.items():
            narrow(bounds, sub, 0, bounds["v"][1])
            for sup, larger in choices.items():
                if smaller & larger == smaller:
                    narrow(bounds, sup, bounds[sub][0], larger.bit_count())
                    narrow(bounds, sub, 0, bounds[sup][1])
        if tuple(bounds.values()) == start:
            break


def regret(bounds, key):
    if key == "both":
        lo = max(bounds["hill"][0], bounds["edlogg"][0])
        hi = max(bounds["hill"][1], bounds["edlogg"][1])
    else:
        lo, hi = bounds[key]
    return max(0, bounds["v"][0] - hi), bounds["v"][1] - lo


def record_for(row, matrix, raw_sources, reference):
    key = row["id"]
    count, columns, indices = action_columns(matrix)
    assert count == int(row["layout_count"])
    hidden = [i for i, glyph in enumerate(row["state"]) if glyph == "H"]
    hi, ed, mi = indices
    assert int(row["hill_tile"]) == hidden[hi]
    survival = [survival_set(col) for col in columns]
    masks = [survival[i] for i in indices]
    safeties = [mask.bit_count() for mask in masks]
    assert safeties[2] == max(map(int.bit_count, survival))
    assert abs(safeties[0] / count - float(row["hill_safety"])) < 1e-8
    relation = ("equal" if masks[0] == masks[1] else
                "hill_superset" if masks[0] & masks[1] == masks[1] else
                "ed_superset" if masks[0] & masks[1] == masks[0] else "incomparable")
    number_counts = [len(set(col) - {77}) for col in columns]
    live_sets = [s for s, ndigits in zip(survival, number_counts) if ndigits > 1]

    bounds = {"v": (1, safeties[2])}
    bounds.update({name: (min(1, k), k) for name, k in zip(NAMES[1:], safeties)})
    sources = []
    exact_seconds = []
    if reference:
        values = reference["tile_values"]
        assert [i for i, _, _ in values] == hidden
        assert [n for _, n, _ in values] == [m.bit_count() for m in survival]
        narrow(bounds, "v", max(v[-1] for v in values), max(v[-1] for v in values))
        for name, idx in zip(NAMES[1:], indices):
            narrow(bounds, name, values[idx][-1], values[idx][-1])
        sources.append("python")
        exact_seconds.append(float(reference["seconds"]))
    for name, proof in raw_sources:
        exact_fields = apply_result(bounds, proof)
        if exact_fields >= 1:
            sources.append(name)
        if exact_fields == 4 and proof.get("seconds"):
            exact_seconds.append(float(proof["seconds"]))
    intersect_choices(bounds, masks, live_sets)
    if len(live_sets) and all(s & masks[0] == s for s in live_sets):
        hill_regret = (0, 0)
    else:
        hill_regret = regret(bounds, "hill")
    if len(live_sets) and all(s & masks[1] == s for s in live_sets):
        ed_regret = (0, 0)
    else:
        ed_regret = regret(bounds, "edlogg")
    if min(hill_regret[1], ed_regret[1]) == 0:
        both_regret = (0, 0)
    else:
        both_regret = regret(bounds, "both")

    result = {
        "id": key, "seed": int(row["seed"]), "layout_index": int(row["layout_index"]),
        "guess_ordinal": int(row["guess_ordinal"]), "layout_count": count, "hidden": len(hidden),
        "whole_bf_status": row["whole_bf_status"],
        "hill_tile": hidden[hi], "edlogg_tile": hidden[ed], "safest_tile": hidden[mi],
        "hill_survivors": safeties[0], "edlogg_survivors": safeties[1], "safest_survivors": safeties[2],
        "survival_relation": relation, "distinct_live_survival_sets": len(set(live_sets)),
        "hill_clue_branches": number_counts[hi], "ed_clue_branches": number_counts[ed],
        "status": "exact" if all(bounds[name][0] == bounds[name][1] for name in NAMES[:3]) else "bounded",
        "exact_sources": "+".join(sources), "fastest_exact_seconds": min(exact_seconds, default=""),
        "known_optimal_tiles": "", "best_safest_winners": ""
    }
    for name, (lo, hi) in bounds.items():
        result[name + "_lo"] = lo
        result[name + "_hi"] = hi
    for name, (lo, hi) in (("hill", hill_regret), ("edlogg", ed_regret), ("both", both_regret)):
        result[name + "_regret_lo"] = lo
        result[name + "_regret_hi"] = hi
    if reference:
        vals = reference["tile_values"]
        result["known_optimal_tiles"] = ",".join(str(t) for t, _, score in vals if score == bounds["v"][0])
        result["best_safest_winners"] = max(score for _, safe, score in vals if safe == safeties[2])
    return result


def pct(row, field):
    return row[field] * 100 / row["layout_count"]


def classify(group, policy, threshold):
    minimum = policy + "_regret_lo"
    maximum = policy + "_regret_hi"
    return {
        "at_least": sum(pct(row, minimum) >= threshold for row in group),
        "below": sum(pct(row, maximum) < threshold for row in group),
        "possible": sum(pct(row, minimum) < threshold <= pct(row, maximum) for row in group),
    }


def statistics(rows):
    exact = [r for r in rows if r["status"] == "exact"]
    checked = len(exact)
    out = {"n": len(rows), "exact": checked}
    if not rows:
        return out
    out["regret_mean_ranges_pp"] = {policy: [mean(pct(row, policy + "_regret_" + end) for row in rows)
                                              for end in ("lo", "hi")]
                                    for policy in ("hill", "edlogg", "both")}
    out["by_threshold_pp"] = {str(t): {policy: classify(rows, policy, t)
                                       for policy in ("hill", "edlogg", "both")}
                               for t in THRESHOLDS}
    if not exact:
        return out
    out["avg_values_exact_pct"] = {name: mean(pct(r, name + "_lo") for r in exact)
                                       for name in NAMES[:3]}
    out["optimal_count"] = {name: sum(r[name + "_lo"] == r["v_lo"] for r in exact)
                                 for name in ("hill", "edlogg")}
    out["ed_ahead"] = sum(r["edlogg_lo"] > r["hill_lo"] for r in exact)
    out["hill_ahead"] = sum(r["edlogg_lo"] < r["hill_lo"] for r in exact)
    out["tie"] = checked - out["ed_ahead"] - out["hill_ahead"]
    out["both_below"] = sum(r["both_regret_lo"] > 0 for r in exact)
    out["regret_exact_pp"] = {p: {stat: f(pct(r, p + "_regret_lo") for r in exact)
                                  for stat, f in (("mean", mean), ("median", median), ("max", max))}
                              for p in ("hill", "edlogg", "both")}
    return out


def summarize(rows):
    axes = {
        "same_tile": lambda r: "same" if r["hill_tile"] == r["edlogg_tile"] else "different",
        "survival_relation": lambda r: r["survival_relation"],
        "seed": lambda r: str(r["seed"]),
        "layouts": lambda r: "0-9999" if r["layout_count"] < 10000 else
                              "10000-19999" if r["layout_count"] < 20000 else "20000-40000",
        "risk_diff_between_solvers_pp": lambda r: "0-1" if abs(pct(r, "hill_survivors")
                                                           - pct(r, "edlogg_survivors")) <= 1.00000001 else ">1",
    }
    breakdown = {}
    for name, key in axes.items():
        groups = defaultdict(list)
        for row in rows:
            groups[key(row)].append(row)
        breakdown[name] = {group: statistics(values) for group, values in groups.items()}
    out = {"all": statistics(rows), "breakdown": breakdown}
    for p in ("hill", "edlogg", "both"):
        out["top_" + p] = sorted([r for r in rows if r[p + "_regret_lo"] > 0],
                                 key=lambda r: pct(r, p + "_regret_lo"), reverse=True)[:10]
    return out


def main():
    p = argparse.ArgumentParser()
    p.add_argument("states", type=Path)
    p.add_argument("matrices", type=Path)
    p.add_argument("per_state", type=Path)
    p.add_argument("summary", type=Path)
    p.add_argument("evidence", type=Path, nargs="+")
    args = p.parse_args()
    raw, reference = read_evidence(args.evidence)
    records = []
    for row in read_states(args.states):
        key = row["id"]
        try:
            records.append(record_for(row, args.matrices / (key + ".txt"), raw[key], reference.get(key)))
        except (ValueError, AssertionError) as err:
            raise RuntimeError(f"inconsistent result for {key}: {err}") from err
    with args.per_state.open("w", encoding="utf-8", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=list(records[0]), delimiter="\t")
        writer.writeheader()
        writer.writerows(records)
    args.summary.write_text(json.dumps(summarize(records), indent=2) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
