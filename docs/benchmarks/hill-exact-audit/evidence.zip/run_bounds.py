import argparse
from collections import Counter
from concurrent.futures import ThreadPoolExecutor
import csv
import json
from pathlib import Path
import subprocess
from time import perf_counter

from exact_oracle import read_states

FIELDS = ("id", "status", "v_lo", "v_hi", "hill_lo", "hill_hi", "edlogg_lo", "edlogg_hi",
          "safest_lo", "safest_hi", "nodes", "greedy_nodes", "seconds")


def exact_ids(paths):
    settled = set()
    for path in paths:
        with path.open(encoding="utf-8-sig", newline="") as file:
            rows = (map(json.loads, file) if path.suffix == ".jsonl" else
                    csv.DictReader(file, delimiter="\t"))
            settled.update(row["id"] for row in rows if row["status"] == "exact")
    return settled


def one(task):
    exe, path, node_limit, time_limit, key, field_count = task
    start = perf_counter()
    try:
        run = subprocess.run([str(exe), str(path), str(node_limit)], capture_output=True,
                             encoding="utf-8", timeout=time_limit, creationflags=subprocess.CREATE_NO_WINDOW)
    except subprocess.TimeoutExpired:
        cells = ["time_limit"] + [""] * (field_count - 3)
    else:
        cells = run.stdout.strip().split("\t")
        if run.returncode or len(cells) != field_count - 2 or cells[0] not in ("exact", "partial"):
            raise RuntimeError(f"{key}: status {run.returncode} / {run.stdout.strip()} / {run.stderr.strip()}")
    return [key, *cells, round(perf_counter() - start, 6)]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("exe", type=Path)
    parser.add_argument("states", type=Path)
    parser.add_argument("matrices", type=Path)
    parser.add_argument("out", type=Path)
    parser.add_argument("--jobs", type=int, default=2)
    parser.add_argument("--node-limit", type=int, default=1000000)
    parser.add_argument("--time-limit", type=float, default=18)
    parser.add_argument("--exclude", nargs="*", type=Path, default=[])
    parser.add_argument("--profile", action="store_true")
    args = parser.parse_args()
    fields = FIELDS
    if args.profile:
        fields = FIELDS[:-1] + ("witness_column", "greedy_best", "greedy_hill", "greedy_edlogg",
                                "greedy_safest", "root_alternatives", "seconds")
    settled = exact_ids(args.exclude)
    states = sorted((row for row in read_states(args.states) if row["id"] not in settled),
                    key=lambda row: (int(row["layout_count"]), row["id"]))
    tasks = [(args.exe.resolve(), args.matrices / (row["id"] + ".txt"),
              args.node_limit, args.time_limit, row["id"], len(fields)) for row in states]
    counts = Counter()
    with args.out.open("w", encoding="utf-8", newline="") as file:
        writer = csv.writer(file, delimiter="\t")
        writer.writerow(fields)
        with ThreadPoolExecutor(max_workers=args.jobs) as pool:
            for result in pool.map(one, tasks):
                writer.writerow(result)
                file.flush()
                counts[result[1]] += 1
                if sum(counts.values()) % 10 == 0:
                    print(sum(counts.values()), len(states), dict(counts), flush=True)
    print(dict(counts), flush=True)


if __name__ == "__main__":
    main()
