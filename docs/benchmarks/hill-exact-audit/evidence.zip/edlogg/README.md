# EdLogg visible-state probe

Built from EdLogg/MineSweeper commit `2e8868d737bf4e5de79ea9b711a30a51d9debe64` with Zig 0.14.1 and Clang 19.1.7 for 64-bit Windows GNU. Build from this directory with PowerShell.

```powershell
python -m pip install --target .\toolchain ziglang==0.14.1
& .\build.ps1
```

The build reads the pinned commit from the scratch clone two directories above. It prepares a separate source copy in `src` and builds `edlogg_probe_v3.exe`.

```powershell
& .\edlogg_probe_v3.exe .\states.tsv
& .\edlogg_probe_v3.exe --next-reveal .\states.tsv
```

Inputs are headerless TSV with an ID and 480 row-major visible cells. Use `H` for a hidden cell, `M` for a known mine, and `0` through `8` for open clues. A filename of `-` reads standard input. Board size is 30 by 16 with 99 total mines.

Output is `id<TAB>tile<TAB>safety<TAB>method`. The tile is a zero-based row-major index. Guess methods report EdLogg’s estimated immediate safety. A flag reports 0, and a certain clear or chord reports 1.

- `RULE_1_FLAG` or `DEDUCE_FLAG` returns the first hidden tile EdLogg flagged in this action.
- `RULE_2_CHORD` returns the open clue that EdLogg chose as the chord anchor.
- `DEDUCE_CLEAR` returns the first certain reveal. `GUESS_0`, `GUESS_1`, `GUESS_2`, `GAMETREE`, and `SUPERLOC` return the hidden tile the corresponding rule selected.
- `--next-reveal` applies all flags in each provable flag action and continues to the first reveal or chord. An emitted chord may depend on those inferred flags.
- `COMPLETE`, `INVALID_STATE`, and `NO_MOVE` use tile −1 and safety `NA`. The latter two also print a reason on standard error and set a nonzero exit code.

The executable uses EdLogg’s ordinary `MakeMove` order and UI defaults. These include the jar SuperLoc method, the SuperLoc multiplier, a 0.96 guess threshold, top-to-bottom preference, and a default GameTree solution threshold of 1,000. The adapter replaces application of a reveal with a recorded action and removes true-layout outcome counters. Its linked code receives only the visible cells and the board's fixed dimensions and mine total. It recognizes a zero-clue chord when a manually supplied partial state leaves hidden cells beside an open zero. It reports identified fixed workspace limits as row-level errors.

The GameTree solution-value buffer is cleared for each input board. In the pinned early-GameTree code a global perimeter index can reach a byte beyond the locally populated solution row, so resetting the buffer reproduces fresh-process behavior. The adapter leaves the upstream index calculation in place.

The 283 selected study rows matched fresh-process, forward-batch, and reverse-batch results. The two larger project first-guess cohorts supplied another 8,380 legal recommendations, and the original 376 Hill pilot states supplied 376 legal actions. Verification checks inspected true layouts outside the CLI to validate certain actions. The final build matched the canonical study outputs and all 8,380 project first-guess recommendations. A synthetic state with 21 disconnected frontier components produced a native capacity diagnostic, and the following row still returned the expected action.

