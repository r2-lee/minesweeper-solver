import argparse
from collections import Counter
from concurrent.futures import ThreadPoolExecutor
import csv
from pathlib import Path
import subprocess
from time import perf_counter

from exact_oracle import read_states


FIELDS = ("id", "status", "v", "hill", "edlogg", "safest", "nodes", "seconds")


def one(task):
    exe, path, node_limit, time_limit, key = task
    start = perf_counter()
    try:
        run = subprocess.run([str(exe), str(path), str(node_limit)], capture_output=True,
                             encoding="utf-8", timeout=time_limit, creationflags=subprocess.CREATE_NO_WINDOW)
    except subprocess.TimeoutExpired:
        cells = ["time_limit"] + [""] * 5
    else:
        cells = run.stdout.strip().split("\t")
        if run.returncode or len(cells) != 6 or cells[0] not in ("exact", "budget"):
            raise RuntimeError(f"{key}: status {run.returncode} / {run.stdout.strip()} / {run.stderr.strip()}")
    return [key, *cells, round(perf_counter() - start, 6)]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("exe", type=Path)
    parser.add_argument("states", type=Path)
    parser.add_argument("matrices", type=Path)
    parser.add_argument("out", type=Path)
    parser.add_argument("--jobs", type=int, default=2)
    parser.add_argument("--node-limit", type=int, default=500000)
    parser.add_argument("--time-limit", type=float, default=20)
    args = parser.parse_args()
    states = sorted(read_states(args.states), key=lambda r: (int(r["layout_count"]), r["id"]))
    tasks = [(args.exe.resolve(), args.matrices / (row["id"] + ".txt"),
              args.node_limit, args.time_limit, row["id"]) for row in states]
    counts = Counter()
    with args.out.open("w", encoding="utf-8", newline="") as file:
        writer = csv.writer(file, delimiter="\t")
        writer.writerow(FIELDS)
        with ThreadPoolExecutor(max_workers=args.jobs) as pool:
            for result in pool.map(one, tasks):
                writer.writerow(result)
                file.flush()
                counts[result[1]] += 1
                if sum(counts.values()) % 10 == 0:
                    print(sum(counts.values()), len(states), dict(counts), flush=True)
    print(dict(counts), flush=True)


if __name__ == "__main__":
    main()
