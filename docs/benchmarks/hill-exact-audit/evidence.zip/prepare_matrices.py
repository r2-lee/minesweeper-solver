import argparse
import csv
from pathlib import Path
import sys
from exact_oracle import enumerate_layouts, read_states, ROWS, COLS, MINES


def make_matrix(near, hidden, flagged, layouts):
    columns = {cell: i for i, cell in enumerate(hidden)}
    static_digits = [sum(tile in flagged for tile in near[cell]) for cell in hidden]
    adjacency = {cell: [columns[tile] for tile in near[cell] if tile in columns] for cell in hidden}
    output = [bytearray(b"M" * len(layouts)) for _ in hidden]
    for i, mines in enumerate(layouts):
        digits = static_digits.copy()
        for mine in mines:
            for j in adjacency[mine]:
                digits[j] += 1
        for j, cell in enumerate(hidden):
            if cell not in mines:
                output[j][i] = 48 + digits[j]
    return output


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("project", type=Path)
    parser.add_argument("states", type=Path)
    parser.add_argument("edlogg", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    sys.path.insert(0, str(args.project.resolve()))
    with args.edlogg.open(encoding="utf-8-sig", newline="") as f:
        ed_moves = {i: (int(tile), float(safety), method) for i, tile, safety, method in csv.reader(f, delimiter="\t")}
    args.output.mkdir(parents=True, exist_ok=True)
    n = 0
    for row in read_states(args.states):
        near, hidden, flagged, layouts = enumerate_layouts(row["state"], ROWS, COLS, MINES, 50000)
        assert len(layouts) == int(row["layout_count"]), row["id"]
        table = make_matrix(near, hidden, flagged, layouts)
        hill = hidden.index(int(row["hill_tile"]))
        ed_tile, ed_safety, method = ed_moves[row["id"]]
        if method == "RULE_2_CHORD":
            ed_tile = next(tile for tile in near[ed_tile] if tile in hidden)
        ed = hidden.index(ed_tile)
        survivors = [len(layouts) - column.count(77) for column in table]
        assert abs(survivors[hill] / len(layouts) - float(row["hill_safety"])) < 1e-8, row["id"]
        if abs(survivors[ed] / len(layouts) - ed_safety) > 1e-8:
            print(row["id"], "EdLogg reported survival", ed_safety,
                  "exact", survivors[ed] / len(layouts), "method", method, file=sys.stderr)
        safest = max(range(len(hidden)), key=lambda i: survivors[i])
        with (args.output / (row["id"] + ".txt")).open("wb") as stream:
            stream.write(f"{len(layouts)} {len(hidden)} {hill} {ed} {safest}\n".encode())
            for column in table:
                stream.write(column + b"\n")
        n += 1
    print(f"Prepared {n} matrices")


if __name__ == "__main__":
    main()
