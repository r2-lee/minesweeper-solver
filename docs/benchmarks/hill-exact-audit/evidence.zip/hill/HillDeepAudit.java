package minesweeper.solver;

import java.io.BufferedReader;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import minesweeper.gamestate.GameStateModel;
import minesweeper.gamestate.GameStateReader;
import minesweeper.solver.settings.SolverSettings;
import minesweeper.structure.Location;

public final class HillDeepAudit {
    private static final int WIDTH = 30;
    private static final int HEIGHT = 16;

    static final class AuditSettings extends SolverSettings {
        AuditSettings(long nodeLimit) {
            this.bruteForceMaxNodes = nodeLimit;
            this.bruteForceTreeDepth = 0;
            this.singleThread = true;
        }
    }

    private record Worlds(String id, List<Location> cells, List<byte[]> rows, int hill, int ed, int safest) {}

    private record Score(int safe, Integer won, long nodes, long millis, int processed, int total) {}

    private record Case(String id, String state, int layouts) {}

    private static Location tile(int index) {
        return new Location(index % WIDTH, index / WIDTH);
    }

    private static int index(Location tile) {
        return tile.x + WIDTH * tile.y;
    }

    private static Worlds readWorlds(BufferedReader source) throws IOException {
        String header = source.readLine();
        if (header == null) {
            return null;
        }
        String[] fields = header.split("\t");
        String id = fields[0];
        int count = Integer.parseInt(fields[1]);
        int hill = Integer.parseInt(fields[2]);
        int ed = Integer.parseInt(fields[3]);
        List<Location> locations = new ArrayList<>();
        for (String cell : fields[4].split(",")) {
            locations.add(tile(Integer.parseInt(cell)));
        }
        List<byte[]> rows = new ArrayList<>(count);
        for (int row = 0; row < count; ++row) {
            String text = source.readLine();
            if (text == null || text.length() != locations.size()) {
                throw new IOException("Invalid layout length in " + id);
            }
            byte[] values = new byte[locations.size()];
            for (int col = 0; col < values.length; ++col) {
                char value = text.charAt(col);
                if (value == 'M') {
                    values[col] = GameStateModel.MINE;
                } else if ('0' <= value && value <= '8') {
                    values[col] = (byte) (value - '0');
                } else {
                    throw new IOException("Invalid layout clue in " + id);
                }
            }
            rows.add(values);
        }
        return new Worlds(id, locations, rows, hill, ed, -1);
    }

    private static Score score(Worlds world, int forcedTile, Solver solver, int lowerBound) {
        int forcedIndex = forcedTile < 0 ? -1 : world.cells().indexOf(tile(forcedTile));
        if (forcedIndex < 0 && forcedTile >= 0) {
            throw new IllegalArgumentException("Forced tile is not hidden: " + forcedTile);
        }
        List<byte[]> survivors = new ArrayList<>(world.rows().size());
        for (byte[] layout : world.rows()) {
            if (forcedIndex < 0 || layout[forcedIndex] != GameStateModel.MINE) {
                survivors.add(layout);
            }
        }
        int count = survivors.size();
        if (count <= 1) {
            return new Score(count, count, 0, 0, 0, 0);
        }
        // Restricting the root to every available tile disables the dynamic
        // cap extension while leaving the set of available moves intact.
        var analysis = new BruteForceAnalysis(solver, world.cells(), count, world.id(), world.cells());
        for (byte[] layout : survivors) {
            analysis.addSolution(layout);
        }
        if (lowerBound != 0) {
            analysis.setWinningLowerBound(lowerBound);
        }
        long started = System.nanoTime();
        analysis.process();
        long millis = (System.nanoTime() - started) / 1_000_000L;
        Integer won = null;
        if (analysis.isComplete()) {
            won = analysis.getSolveChance().multiply(BigDecimal.valueOf(count))
                .setScale(0, RoundingMode.HALF_UP).intValueExact();
            if (won < 1 || won > count) {
                throw new IllegalStateException("Invalid winning count for " + world.id());
            }
        }
        return new Score(count, won, analysis.getNodeCount(), millis, analysis.getMovesProcessed(),
            analysis.getMovesToProcess());
    }

    private static void printScore(Worlds world, String label, int tile, Score score) {
        System.out.printf("%s\t%s\t%d\t%d\t%d\t%s\t%d\t%d\t%d\t%d%n", world.id(), label,
            tile, world.rows().size(), score.safe(), display(score), score.nodes(), score.millis(),
            score.processed(), score.total());
    }

    private static String display(Score score) {
        return score == null || score.won() == null ? "" : Integer.toString(score.won());
    }

    private static List<Case> sortedCases(Path states) throws IOException {
        List<Case> inputs = new ArrayList<>();
        try (var source = Files.newBufferedReader(states)) {
            String header = source.readLine();
            if (header == null || !header.startsWith("id\tseed\tlayout_index\tguess_ordinal\tstate\t")) {
                throw new IOException("Unexpected state TSV header");
            }
            for (String line; (line = source.readLine()) != null;) {
                String[] fields = line.split("\t");
                inputs.add(new Case(fields[0], fields[4], Integer.parseInt(fields[8])));
            }
        }
        inputs.sort(Comparator.comparingInt(Case::layouts).thenComparing(Case::id));
        return inputs;
    }

    private static Worlds readMatrix(Path folder, Case data) throws IOException {
        List<Location> cells = new ArrayList<>();
        for (int i = 0; i < data.state().length(); ++i) {
            if (data.state().charAt(i) == 'H') {
                cells.add(tile(i));
            }
        }
        try (var source = Files.newBufferedReader(folder.resolve(data.id() + ".txt"))) {
            String[] header = source.readLine().split(" ");
            int layouts = Integer.parseInt(header[0]);
            int columns = Integer.parseInt(header[1]);
            int hill = index(cells.get(Integer.parseInt(header[2])));
            int ed = index(cells.get(Integer.parseInt(header[3])));
            int safest = index(cells.get(Integer.parseInt(header[4])));
            if (columns != cells.size() || layouts != data.layouts()) {
                throw new IOException("Inconsistent world matrix dimensions for " + data.id());
            }
            var rows = new ArrayList<byte[]>(layouts);
            for (int i = 0; i < layouts; ++i) {
                rows.add(new byte[columns]);
            }
            for (int col = 0; col < columns; ++col) {
                String line = source.readLine();
                if (line == null || line.length() != layouts) {
                    throw new IOException("Invalid column width for " + data.id());
                }
                for (int row = 0; row < layouts; ++row) {
                    char value = line.charAt(row);
                    if (value != 'M' && (value < '0' || value > '8')) {
                        throw new IOException("Invalid clue for " + data.id());
                    }
                    rows.get(row)[col] = value == 'M' ? GameStateModel.MINE : (byte) (value - '0');
                }
            }
            return new Worlds(data.id(), cells, rows, hill, ed, safest);
        }
    }

    private static void prepareSafety(Worlds world, int[] tiles, int[] columns, int[] survivors, boolean[][] subset) {
        int[] counts = new int[world.cells().size()];
        for (byte[] row : world.rows()) {
            for (int col = 0; col < row.length; ++col) {
                if (row[col] != GameStateModel.MINE) {
                    ++counts[col];
                }
            }
        }
        for (int i = 0; i < tiles.length; ++i) {
            columns[i] = i == 0 ? -1 : world.cells().indexOf(tile(tiles[i]));
            survivors[i] = i == 0 ? java.util.Arrays.stream(counts).max().orElseThrow() : counts[columns[i]];
        }
        for (int i = 0; i < tiles.length; ++i) {
            for (int j = 0; j < tiles.length; ++j) {
                // Whether every world that survives choice i survives choice j.
                subset[i][j] = i != 0 || j == 0 || survivors[j] == world.rows().size();
                if (i != 0 && j != 0 && i != j) {
                    for (byte[] row : world.rows()) {
                        if (row[columns[i]] != GameStateModel.MINE && row[columns[j]] == GameStateModel.MINE) {
                            subset[i][j] = false;
                            break;
                        }
                    }
                }
            }
        }
    }

    private record Bounds(int lower, int upper) {}

    private static Bounds bounds(Worlds world, int[] survivors, boolean[][] subset, Score[] scores,
                                 int selected, int lower) {
        int upper = survivors[selected];
        for (int i = 0; i < scores.length; ++i) {
            Score previous = scores[i];
            if (previous == null || previous.won() == null) {
                continue;
            }
            if (subset[i][selected]) {
                lower = Math.max(lower, previous.won());
            }
            if (subset[selected][i]) {
                upper = Math.min(upper, previous.won());
            }
        }
        if (lower > upper) {
            throw new IllegalStateException("Incompatible winning bounds for " + world.id());
        }
        return new Bounds(lower, upper);
    }

    private static Score boundedScore(Worlds world, Solver solver, int[] tiles, int[] survivors,
                                      boolean[][] subset, Score[] scores, int selected, int minimum) {
        Bounds bounds = bounds(world, survivors, subset, scores, selected, minimum);
        if (bounds.lower() == bounds.upper()) {
            return new Score(survivors[selected], bounds.lower(), 0, 0, 0, 0);
        }
        Score result = score(world, tiles[selected], solver, bounds.lower());
        if (result.won() != null && (result.won() < bounds.lower() || result.won() > bounds.upper())) {
            throw new IllegalStateException("Computed winning count outside certified bounds for " + world.id());
        }
        return result;
    }

    private static void scoreMatrix(Worlds world, Solver solver, String[] previous, int[] minima, int only) {
        int[] tiles = {-1, world.hill(), world.ed(), world.safest()};
        int[] columns = new int[tiles.length];
        int[] survivors = new int[tiles.length];
        boolean[][] subset = new boolean[tiles.length][tiles.length];
        prepareSafety(world, tiles, columns, survivors, subset);
        long nodes = 0;
        long millis = 0;
        int finished = 0;
        Score[] scores = new Score[tiles.length];
        for (int i = 0; i < previous.length; ++i) {
            if (!previous[i].equals("-")) {
                int value = Integer.parseInt(previous[i]);
                if (value < 0 || value > survivors[i]) {
                    throw new IllegalStateException("Cached winning count outside safety bound");
                }
                scores[i] = new Score(survivors[i], value, 0, 0, 0, 0);
            }
        }
        // Each exact forced-action value bounds the unrestricted search and
        // any forced subset containing it. Score those actions first.
        for (int i : new int[] {1, 2, 3, 0}) {
            if (scores[i] == null && (only == -1 || only == i)) {
                Score result = boundedScore(world, solver, tiles, survivors, subset, scores, i, minima[i]);
                scores[i] = result;
                nodes += result.nodes();
                millis += result.millis();
            }
        }
        for (int i = 0; i < scores.length; ++i) {
            if (scores[i] == null || scores[i].won() == null) {
                Bounds bounds = bounds(world, survivors, subset, scores, i, minima[i]);
                if (bounds.lower() == bounds.upper()) {
                    scores[i] = new Score(survivors[i], bounds.lower(), 0, 0, 0, 0);
                }
            }
            if (scores[i] != null && scores[i].won() != null) {
                ++finished;
            }
        }
        String status = switch (finished) {
            case 0 -> "node_limit";
            case 4 -> "exact";
            default -> "partial";
        };
        System.out.printf(Locale.ROOT, "%s\t%s\t%s\t%s\t%s\t%s\t%d\t%.3f%n", world.id(), status,
            display(scores[0]), display(scores[1]), display(scores[2]), display(scores[3]), nodes, millis / 1000.0);
    }

    private static Solver auditSolver(long nodeLimit) {
        GameStateModel game = GameStateReader.loadMines(WIDTH, HEIGHT, List.of(tile(0)), List.of());
        return new Solver(game, new AuditSettings(nodeLimit), false);
    }

    private static void runMatrices(String[] args) throws IOException {
        if (args.length != 6 && args.length != 10 && args.length != 15) {
            throw new IllegalArgumentException(
                "Usage: HillDeepAudit --matrices STATES FOLDER NODE_CAP FIRST LAST [V HILL ED SAFEST]"
                + " [MIN_V MIN_HILL MIN_ED MIN_SAFEST ONLY_SCORE_INDEX]"
            );
        }
        Solver solver = auditSolver(Long.parseLong(args[3]));
        Path folder = Path.of(args[2]);
        List<Case> cases = sortedCases(Path.of(args[1]));
        int first = Integer.parseInt(args[4]);
        int last = Math.min(cases.size(), Integer.parseInt(args[5]));
        if (args.length > 6 && last - first != 1) {
            throw new IllegalArgumentException("Prior values may be supplied for one state at a time");
        }
        String[] previous = java.util.Arrays.copyOfRange(args, 6, Math.min(args.length, 10));
        int[] minima = new int[4];
        int only = -1;
        if (args.length == 15) {
            for (int i = 0; i < minima.length; ++i) {
                minima[i] = Integer.parseInt(args[10 + i]);
            }
            only = Integer.parseInt(args[14]);
            if (only < -1 || only >= minima.length) {
                throw new IllegalArgumentException("Invalid score index " + only);
            }
        }
        System.out.println("id\tstatus\tV\thill\ted\tsafest\tnodes\tseconds");
        for (int i = first; i < last; ++i) {
            scoreMatrix(readMatrix(folder, cases.get(i)), solver, previous, minima, only);
        }
    }

    public static void main(String[] args) throws IOException {
        if (args.length > 0 && args[0].equals("--matrices")) {
            runMatrices(args);
            return;
        }
        if (args.length < 2 || args.length > 3) {
            throw new IllegalArgumentException("Usage: HillDeepAudit WORLDS NODE_CAP [MAX_CASES]");
        }
        long nodeLimit = Long.parseLong(args[1]);
        int caseLimit = args.length == 3 ? Integer.parseInt(args[2]) : Integer.MAX_VALUE;
        Solver solver = auditSolver(nodeLimit);
        System.out.println("id\tmetric\ttile\tlayouts\tsafe_layouts\twinning_layouts\tnodes\tmillis\troot_moves_processed\troot_moves_total");
        try (var source = Files.newBufferedReader(Path.of(args[0]))) {
            for (int i = 0; i < caseLimit; ++i) {
                Worlds world = readWorlds(source);
                if (world == null) {
                    break;
                }
                Map<Integer, String> moves = new LinkedHashMap<>();
                moves.put(-1, "V");
                moves.put(world.hill(), "Q_hill");
                if (world.ed() >= 0) {
                    moves.merge(world.ed(), "Q_ed", (a, b) -> a + "," + b);
                }
                for (var entry : moves.entrySet()) {
                    printScore(world, entry.getValue(), entry.getKey(), score(world, entry.getKey(), solver, 0));
                }
            }
        }
    }
}
