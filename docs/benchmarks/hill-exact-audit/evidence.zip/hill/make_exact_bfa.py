from pathlib import Path
import sys


HERE = Path(__file__).resolve().parent
UPSTREAM = HERE.parent.parent / "david-java" / "MineSweeperSolver" / "src" / "minesweeper" / "solver" / "BruteForceAnalysis.java"


def replace(source, old, new):
    if source.count(old) != 1:
        raise ValueError(f"Upstream excerpt is absent or ambiguous: {old}")
    return source.replace(old, new)


def replace_section(source, start, end, replacement):
    begin = source.index(start)
    finish = source.index(end, begin)
    return source[:begin] + replacement + source[finish:]


def make_source():
    source = UPSTREAM.read_text(encoding="utf8")
    source = replace(source, 'private final Random rng = new Random();', 'private final Random rng = new Random(0);')
    source = replace(source, '\t\tprivate long linkedHash;', '\t\tprivate long linkedHash;\n\t\tprivate short linkedTo = -1;')
    source = replace(
        source,
        "\tprivate Node currentNode;",
        """	private Node currentNode;
	private int winningLowerBound;

	void setWinningLowerBound(int lowerBound) {
		if (lowerBound < 0 || lowerBound > allSolutions.size()) {
			throw new IllegalArgumentException("Invalid certified winning lower bound");
		}
		this.winningLowerBound = lowerBound;
	}
""",
    )
    source = replace(
        source,
        "\t\tint best = 0;",
        "\t\tint best = this.winningLowerBound;\n\t\ttop.winningLines = best;",
    )
    source = replace_section(
        source,
        "\t\tprivate List<Node> buildChildNodes(Node parent) {",
        "\n\t\t@Override\n\t\tpublic int compareTo(LivingLocation o)",
        """		private List<Node> buildChildNodes(Node parent) {

			allSolutions.sortSolutions(parent.startSolution, parent.endSolution, this.index);
			int index = parent.startSolution;
			while (index < parent.endSolution && allSolutions.get(index)[this.index] == GameStateModel.MINE) {
				index++;
			}

			Node[] work = new Node[9];
			List<Node> result = new ArrayList<>(9);
			for (int value = this.minValue; value <= this.maxValue; value++) {
				int first = index;
				while (index < parent.endSolution && allSolutions.get(index)[this.index] == value) {
					index++;
				}
				if (index == first) {
					continue; // A clue in the integer range can have no matching layouts.
				}

				Position position = new Position(parent.position, this.index, value);
				Node child = cache.get(position);
				if (child == null) {
					child = new Node(position);
					child.startSolution = first;
					child.endSolution = index;
				} else {
					if (!child.fromCache || child.getSolutionSize() != index - first) {
						throw new IllegalStateException("Inconsistent cached branch cardinality");
					}
					cacheHit++;
					cacheWinningLines += child.winningLines;
				}
				work[value] = child;
				result.add(child);
			}
			if (index != parent.endSolution) {
				throw new IllegalStateException("Some layouts fell outside the clue range");
			}
			this.children = work;
			Collections.sort(result);
			return result;
		}

		private boolean sameSafety(LivingLocation other, int first, int end) {
			for (int world = first; world < end; world++) {
				byte[] layout = allSolutions.get(world);
				boolean mineHere = layout[this.index] == GameStateModel.MINE;
				boolean mineThere = layout[other.index] == GameStateModel.MINE;
				if (mineHere != mineThere) {
					return false;
				}
			}
			return true;
		}

		private void linkToEquivalent(List<LivingLocation> previous, int first, int end) {
			for (LivingLocation prior : previous) {
				// The hash is only a filter. The safety sets must actually coincide.
				if (prior.linkedHash == this.linkedHash && sameSafety(prior, first, end)) {
					this.linked = true;
					this.linkedTo = prior.linked ? prior.linkedTo : prior.index;
					return;
				}
			}
		}
""",
    )
    source = replace_section(
        source,
        "\t\tprivate void determineLivingLocations(final List<LivingLocation> liveLocs, int index) {",
        "\n\t\t@Override\n\t\tpublic int hashCode()",
        """		private void determineLivingLocations(final List<LivingLocation> liveLocs, int index) {
			this.livingLocations = new ArrayList<>(liveLocs.size());
			boolean safeMoveFound = false;
			for (LivingLocation location : liveLocs) {
				if (location.index == index) {
					continue;
				}
				LivingLocation candidate = new LivingLocation(location.index);
				if (safeMoveFound) {
					// The safe informative action dominates here. Keep subsequent
					// candidates for the children and calculate their details there.
					candidate.mineCount = this.getSolutionSize();
					candidate.distinctValues = 2;
					candidate.minValue = location.minValue;
					candidate.maxValue = location.maxValue;
					this.livingLocations.add(candidate);
					continue;
				}

				int[] counts = resetValues(0);
				for (int j = this.startSolution; j < this.endSolution; j++) {
					int value = allSolutions.get(j)[location.index];
					if (value == GameStateModel.MINE) {
						candidate.mineCount++;
						candidate.linkedHash -= allSolutions.getHash(j);
					} else {
						counts[value]++;
						candidate.linkedHash += allSolutions.getHash(j);
					}
				}
				for (byte clue = location.minValue; clue <= location.maxValue; clue++) {
					if (counts[clue] > 0) {
						if (candidate.distinctValues == 0) {
							candidate.minValue = clue;
						}
						candidate.maxValue = clue;
						candidate.distinctValues++;
					}
				}
				if (candidate.distinctValues > 1) {
					candidate.linkToEquivalent(this.livingLocations, this.startSolution, this.endSolution);
					this.livingLocations.add(candidate);
					if (candidate.mineCount == 0 && this.getSolutionSize() > 20) {
						safeMoveFound = true;
					}
				}
			}
			Collections.sort(this.livingLocations);
		}
""",
    )
    source = replace(
        source,
        "return - (this.endSolution - this.startSolution) - (o.endSolution - o.startSolution);",
        "return Integer.compare(o.getSolutionSize(), this.getSolutionSize());",
    )
    source = replace(
        source,
        "if (pm.linkedHash == move.linkedHash) {",
        "if (pm.location.equals(locations.get(move.linkedTo))) {",
    )
    source = replace_section(
        source,
        "\t\t\t\talive.linkedHash = hash;",
        "\n\t\t\t\tliving.add(alive);",
        """				alive.linkedHash = hash;
				alive.linkToEquivalent(living, result.startSolution, result.endSolution);
				alive.pruned = alive.linked;
""",
    )
    return source


if __name__ == "__main__":
    Path(sys.argv[1]).write_text(make_source(), encoding="utf8")
