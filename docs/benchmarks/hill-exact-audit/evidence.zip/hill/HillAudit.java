package minesweeper.solver;

import java.io.BufferedWriter;
import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import minesweeper.gamestate.GameStateModel;
import minesweeper.gamestate.GameStateReader;
import minesweeper.gamestate.MoveMethod;
import minesweeper.solver.settings.PlayStyle;
import minesweeper.solver.settings.SettingsFactory;
import minesweeper.solver.settings.SettingsFactory.Setting;
import minesweeper.solver.settings.SolverSettings;
import minesweeper.structure.Action;
import minesweeper.structure.Location;

public final class HillAudit {
    private static final int WIDTH = 30;
    private static final int HEIGHT = 16;
    private static final int MINES = 99;
    private static final int FIRST = 3 * WIDTH + 3;
    private static final int SOLUTION_CAP = 40000;
    private static final String HEADER = String.join("\t",
        "id", "seed", "layout_index", "guess_ordinal", "state", "hill_tile", "hill_safety",
        "hill_method", "layout_count", "whole_bf_status", "isolated_bf_status",
        "isolated_tiles", "whole_bf_iterations", "whole_bf_nodes", "hidden", "mines_left");

    // The original classes stay on the classpath. These fields are read after
    // the solver has returned its actions, before any action is applied.
    private static final Field BOARD = solverField("boardState");
    private static final Field PE = solverField("pe");
    private static final Field WHOLE = solverField("bf");
    private static final Field ACTIVE = solverField("bruteForceAnalysis");

    private static Field solverField(String name) {
        try {
            Field field = Solver.class.getDeclaredField(name);
            field.setAccessible(true);
            return field;
        } catch (ReflectiveOperationException error) {
            throw new ExceptionInInitializerError(error);
        }
    }

    private static Location tile(int index) {
        return new Location(index % WIDTH, index / WIDTH);
    }

    private static int index(Location tile) {
        return tile.x + WIDTH * tile.y;
    }

    private static GameStateModel setup(String layout) {
        if (layout.length() != WIDTH * HEIGHT) {
            throw new IllegalArgumentException("Invalid layout width or height");
        }
        var mineCells = new ArrayList<Location>(MINES);
        for (int i = 0; i < layout.length(); ++i) {
            if (layout.charAt(i) == '1') {
                mineCells.add(tile(i));
            }
        }
        if (mineCells.size() != MINES || layout.charAt(FIRST) != '0') {
            throw new IllegalArgumentException("Invalid layout");
        }
        GameStateModel game = GameStateReader.loadMines(WIDTH, HEIGHT, mineCells, List.of());
        game.doAction(new Action(tile(FIRST), Action.CLEAR));
        if (game.query(tile(FIRST)) != 0) {
            throw new IllegalArgumentException("The starting click must reveal a zero");
        }
        return game;
    }

    private record Snapshot(String state, int hidden, int minesLeft) {}

    private static Snapshot snapshot(GameStateModel game, BoardState board, String layout) {
        StringBuilder state = new StringBuilder(WIDTH * HEIGHT);
        int hidden = 0;
        int mines = 0;
        for (int i = 0; i < WIDTH * HEIGHT; ++i) {
            int x = i % WIDTH;
            int y = i / WIDTH;
            int info = game.query(board.getLocation(x, y));
            if (board.isConfirmedMine(x, y)) {
                if (layout.charAt(i) != '1' || (info != GameStateModel.HIDDEN && info != GameStateModel.FLAG)) {
                    throw new IllegalStateException("False confirmed mine at " + i);
                }
                state.append('M');
                ++mines;
            } else if (info == GameStateModel.HIDDEN) {
                state.append('H');
                ++hidden;
            } else if (0 <= info && info <= 8) {
                state.append((char) ('0' + info));
            } else {
                throw new IllegalStateException("Unexpected board value " + info + " at " + i);
            }
        }
        if (hidden != board.getTotalUnrevealedCount() || mines != board.getConfirmedMineCount()) {
            throw new IllegalStateException("Visible state disagrees with solver counts");
        }
        return new Snapshot(state.toString(), hidden, MINES - mines);
    }

    private static String bruteForceStatus(BruteForce force, BigInteger iterationCap) {
        if (!force.hasRun()) {
            if (force.getIterations() == null || force.getIterations().compareTo(iterationCap) <= 0) {
                throw new IllegalStateException("Unexpected enumeration failure");
            }
            return "iteration_cap";
        }
        BruteForceAnalysisModel tree = force.getBruteForceAnalysis();
        if (tree == null) {
            return force.hasCertainClear() ? "certain_clear" : "no_tree";
        }
        if (!tree.isComplete()) {
            return "node_cap";
        }
        return tree.allDead() ? "completed_all_dead" : "completed";
    }

    private static String observe(int seed, int id, int ordinal, GameStateModel game, Solver solver,
                                  SolverSettings settings, String layout, Action action,
                                  ProbabilityEngineModel pe) throws IllegalAccessException {
        BoardState board = (BoardState) BOARD.get(solver);
        Snapshot snapshot = snapshot(game, board, layout);
        int choice = index(action);
        if (snapshot.state().charAt(choice) != 'H') {
            throw new IllegalStateException("Solver guessed a tile that is already known at " + choice);
        }
        BruteForce whole = (BruteForce) WHOLE.get(solver);
        BruteForceAnalysisModel active = (BruteForceAnalysisModel) ACTIVE.get(solver);

        // The solver tries only its smallest isolated edge and can return its
        // move before reaching the whole-board threshold test.
        BruteForce isolated = null;
        for (BruteForce edge : pe.getIsolatedEdges()) {
            if (isolated == null || edge.getTileCount() < isolated.getTileCount()) {
                isolated = edge;
            }
        }
        boolean isolatedAttempted = isolated != null && isolated.getIterations() != null;
        String edgeStatus = isolatedAttempted
            ? bruteForceStatus(isolated, settings.getBruteForceMaxIterations())
            : (isolated == null ? "none" : "not_attempted");
        boolean isolatedChosen = whole == null && isolatedAttempted && active != null
            && active == isolated.getBruteForceAnalysis() && active.isComplete()
            && (action.getMoveMethod() == MoveMethod.BRUTE_FORCE_DEEP_ANALYSIS
                || (action.getMoveMethod() == MoveMethod.GUESS && active.allDead()
                    && active.getDeadLocations().contains(action)));
        String wholeStatus;
        String iterations = "";
        String nodes = "";
        if (whole != null) {
            wholeStatus = bruteForceStatus(whole, settings.getBruteForceMaxIterations());
            BruteForceAnalysisModel tree = whole.getBruteForceAnalysis();
            iterations = whole.getIterations().toString();
            if (tree != null) {
                nodes = Long.toString(tree.getNodeCount());
            }
        } else if (isolatedChosen) {
            wholeStatus = isolated.getTileCount() == snapshot.hidden()
                ? "isolated_whole_board" : "isolated_component_chosen";
        } else if (pe.allDead() && pe.getDeadLocations().size() != 0) {
            wholeStatus = "pe_all_dead";
        } else if (pe.foundCertainty()) {
            wholeStatus = "certain_clear";
        } else {
            double safeDensity = (double) (snapshot.hidden() - snapshot.minesLeft()) / snapshot.hidden();
            BigDecimal scaled = new BigDecimal(pe.getSolutionCount()).multiply(BigDecimal.valueOf(safeDensity).pow(3));
            if (pe.getSolutionCount().compareTo(BigInteger.valueOf(settings.getBruteForceMaxSolutions())) <= 0
                || scaled.compareTo(BigDecimal.valueOf(settings.getBruteForceVariableSolutions())) <= 0) {
                throw new IllegalStateException("Expected an eligible whole-board run on " + seed + "-" + id
                    + "-" + ordinal + " (" + pe.getSolutionCount() + " solutions)");
            }
            wholeStatus = "threshold_skipped";
        }
        return String.join("\t",
            seed + "-" + id + "-" + ordinal, Integer.toString(seed), Integer.toString(id), Integer.toString(ordinal),
            snapshot.state(), Integer.toString(choice), action.getBigProb().toPlainString(), action.getMoveMethod().name(),
            pe.getSolutionCount().toString(), wholeStatus, edgeStatus,
            isolated == null ? "" : Integer.toString(isolated.getTileCount()), iterations, nodes,
            Integer.toString(snapshot.hidden()), Integer.toString(snapshot.minesLeft()));
    }

    private record Result(List<String> rows, String trace) {}

    private static Result play(int seed, int id, String layout) throws IllegalAccessException {
        GameStateModel game = setup(layout);
        SolverSettings settings = SettingsFactory.GetSettings(Setting.LARGE_ANALYSIS).setSingleThread(true);
        Solver solver = new Solver(game, settings, false);
        solver.setPlayStyle(PlayStyle.NO_FLAG);
        List<String> rows = new ArrayList<>();
        int guesses = 0;
        int firstGuess = -1;
        double safety = 0;
        StringBuilder trace = new StringBuilder();
        for (int step = 0; step < 1000 && game.getGameState() == GameStateModel.STARTED; ++step) {
            solver.start();
            int changes = 0;
            for (Action action : solver.getResult()) {
                boolean guess = action.getAction() == Action.CLEAR && !action.isCertainty();
                int cell = index(action);
                String row = null;
                if (guess && game.query(action) == GameStateModel.HIDDEN) {
                    ProbabilityEngineModel pe = (ProbabilityEngineModel) PE.get(solver);
                    if (pe != null && pe.getSolutionCount().signum() > 0
                        && pe.getSolutionCount().compareTo(BigInteger.valueOf(SOLUTION_CAP)) <= 0) {
                        if (changes != 0) {
                            throw new IllegalStateException("A prior action changed the pre-guess board on " + id);
                        }
                        row = observe(seed, id, guesses + 1, game, solver, settings, layout, action, pe);
                    }
                }
                boolean mined = layout.charAt(cell) == '1';
                if (action.getAction() == Action.FLAG && !mined) {
                    throw new IllegalStateException("False flag at " + cell);
                }
                if (action.getAction() == Action.CLEAR && action.isCertainty() && mined) {
                    throw new IllegalStateException("Certainty hit a mine at " + cell);
                }
                if (row != null) {
                    rows.add(row);
                }
                boolean changed = game.doAction(action);
                if (row != null && !changed) {
                    throw new IllegalStateException("Recorded guess was not a legal click at " + cell);
                }
                if (changed) {
                    ++changes;
                }
                if (guess && changed) {
                    if (firstGuess == -1) {
                        firstGuess = cell;
                    }
                    ++guesses;
                    safety += action.getBigProb().doubleValue();
                    if (trace.length() > 0) {
                        trace.append(',');
                    }
                    trace.append(cell).append(':').append(action.getMoveMethod()).append(':').append(action.getBigProb());
                }
                if (game.getGameState() != GameStateModel.STARTED) {
                    break;
                }
            }
            if (changes == 0) {
                throw new IllegalStateException("No progress on " + seed + "-" + id);
            }
        }
        int won;
        if (game.getGameState() == GameStateModel.WON) {
            won = 1;
        } else if (game.getGameState() == GameStateModel.LOST) {
            won = 0;
        } else {
            throw new IllegalStateException("Unfinished game on " + seed + "-" + id);
        }
        return new Result(rows, id + "\t" + won + "\t" + guesses + "\t" + safety + "\t" + firstGuess + "\t" + trace);
    }

    private static void writeLine(BufferedWriter file, String line) throws java.io.IOException {
        file.write(line);
        file.newLine();
    }

    public static void main(String[] args) throws Exception {
        if (args.length != 6) {
            throw new IllegalArgumentException("Usage: HillAudit SEED LAYOUTS FIRST_INDEX LAST_INDEX_EXCLUSIVE WORKERS OUTPUT_PREFIX");
        }
        int seed = Integer.parseInt(args[0]);
        int first = Integer.parseInt(args[2]);
        int last = Integer.parseInt(args[3]);
        int workers = Integer.parseInt(args[4]);
        List<String> layouts = Files.readAllLines(Path.of(args[1]));
        try (var pool = Executors.newFixedThreadPool(workers);
             var states = Files.newBufferedWriter(Path.of(args[5] + "-states.tsv"));
             var traces = Files.newBufferedWriter(Path.of(args[5] + "-trace.tsv"))) {
            writeLine(states, HEADER);
            var tasks = new ArrayList<Future<Result>>();
            for (String entry : layouts) {
                String[] fields = entry.split("\t", 2);
                int id = Integer.parseInt(fields[0]);
                if (first <= id && id < last) {
                    tasks.add(pool.submit(() -> play(seed, id, fields[1])));
                }
            }
            int count = 0;
            int rows = 0;
            for (Future<Result> task : tasks) {
                Result result = task.get();
                writeLine(traces, result.trace());
                for (String row : result.rows()) {
                    writeLine(states, row);
                    ++rows;
                }
                if (++count % 50 == 0 || count == tasks.size()) {
                    states.flush();
                    traces.flush();
                    System.err.println("Seed " + seed + ": " + count + "/" + tasks.size() + " boards, " + rows + " states");
                }
            }
        }
    }
}
