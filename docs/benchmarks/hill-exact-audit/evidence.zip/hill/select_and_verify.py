import argparse
from collections import Counter
import csv
from decimal import Decimal
from pathlib import Path


HILL_DIR = Path(__file__).resolve().parent
BENCHMARK_DIR = HILL_DIR.parent.parent
WIDTH = 30
HEIGHT = 16
START = 3 * WIDTH + 3
CAP_FAILURES = {"threshold_skipped", "iteration_cap", "node_cap", "no_tree"}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def neighbors(cell):
    x, y = cell % WIDTH, cell // WIDTH
    return [
        ny * WIDTH + nx
        for ny in range(max(0, y - 1), min(HEIGHT, y + 2))
        for nx in range(max(0, x - 1), min(WIDTH, x + 2))
        if (nx, ny) != (x, y)
    ]


NEIGHBORS = tuple(neighbors(cell) for cell in range(WIDTH * HEIGHT))


def indexed_lines(path):
    with path.open(encoding="utf8") as stream:
        return {int(line.partition("\t")[0]): line.rstrip("\r\n") for line in stream}


def verify_snapshot(row, layout, trace):
    state = row["state"]
    identifier = row["id"]
    choice = int(row["hill_tile"])
    ordinal = int(row["guess_ordinal"])
    require(len(state) == WIDTH * HEIGHT and state[START] == "0", f"{identifier}: unexpected board dimensions/start")
    require(state[choice] == "H", f"{identifier}: selected cell is not hidden")
    require(int(row["hidden"]) == state.count("H"), f"{identifier}: hidden-count mismatch")
    require(int(row["mines_left"]) == 99 - state.count("M"), f"{identifier}: mine-count mismatch")
    require(1 < int(row["layout_count"]) <= 40000, f"{identifier}: posterior count outside sample limits")
    require(identifier == f"{row['seed']}-{row['layout_index']}-{ordinal}", f"{identifier}: unexpected identifier")
    for cell, value in enumerate(state):
        if value == "M":
            require(layout[cell] == "1", f"{identifier}: confirmed mine at {cell} inconsistent with layout")
        elif value != "H":
            clue = sum(layout[neighbor] == "1" for neighbor in NEIGHBORS[cell])
            require(layout[cell] == "0" and value == str(clue), f"{identifier}: clue at {cell} inconsistent with layout")
    action = trace.split("\t")[5].split(",")[ordinal - 1]
    tile, method, safety = action.split(":")
    require(int(tile) == choice, f"{identifier}: action disagrees with the trace")
    require(method == row["hill_method"], f"{identifier}: method disagrees with the trace")
    require(Decimal(safety) == Decimal(row["hill_safety"]), f"{identifier}: safety disagrees with the trace")


def read_and_verify(paths):
    input_rows = []
    fields = None
    layouts = {}
    baselines = {}
    verified_boards = set()
    ids = set()
    for path in paths:
        with path.open(encoding="utf8", newline="") as stream:
            reader = csv.DictReader(stream, delimiter="\t")
            rows = list(reader)
            if fields is None:
                fields = reader.fieldnames
            require(fields == reader.fieldnames, f"{path}: inconsistent columns")
        require(rows, f"{path}: no guessing states")
        seeds = {int(row["seed"]) for row in rows}
        require(len(seeds) == 1, f"{path}: expected one seed")
        seed = seeds.pop()
        if seed not in layouts:
            lines = indexed_lines(BENCHMARK_DIR / f"layouts-{seed}-0-5000.tsv")
            layouts[seed] = {index: line.partition("\t")[2] for index, line in lines.items()}
            baselines[seed] = indexed_lines(BENCHMARK_DIR / f"hill-large-{seed}-0-5000.tsv")
        prefix = path.name.removesuffix("-states.tsv")
        traces = indexed_lines(path.with_name(prefix + "-trace.tsv"))
        for index, trace in traces.items():
            require(trace == baselines[seed][index], f"Existing Hill trace differs on seed {seed}, board {index}")
            require((seed, index) not in verified_boards, f"Duplicate board in scans, seed {seed}, board {index}")
            verified_boards.add((seed, index))
        for row in rows:
            index = int(row["layout_index"])
            identifier = row["id"]
            require(identifier not in ids, f"Duplicate state {identifier}")
            ids.add(identifier)
            verify_snapshot(row, layouts[seed][index], traces[index])
        input_rows.extend(rows)
    print(f"Verified {len(verified_boards)} full game traces and {len(input_rows)} pre-click snapshots")
    return fields, sorted(input_rows, key=lambda row: tuple(int(row[key]) for key in ("seed", "layout_index", "guess_ordinal")))


def select(rows, controls_per_bin, isolated_per_seed):
    def board_key(row):
        return row["seed"], row["layout_index"]

    eligible = {kind: {} for kind in ("primary", "isolated", "controls", "isolated-controls")}
    for row in rows:
        status = row["whole_bf_status"]
        if status in CAP_FAILURES:
            kind = "primary"
        elif status == "isolated_component_chosen":
            kind = "isolated"
        elif row["hill_method"] == "BRUTE_FORCE_DEEP_ANALYSIS" and int(row["layout_count"]) <= 4000:
            if status == "completed":
                kind = "controls"
            elif status == "isolated_whole_board" and row["isolated_bf_status"] == "completed":
                kind = "isolated-controls"
            else:
                continue
        else:
            continue
        eligible[kind].setdefault(board_key(row), row)

    isolated = []
    isolated_counts = Counter()
    for row in eligible["isolated"].values():
        seed = row["seed"]
        if isolated_counts[seed] < isolated_per_seed:
            isolated.append(row)
            isolated_counts[seed] += 1

    controls = {"controls": [], "isolated-controls": []}
    for kind, selected in controls.items():
        control_counts = Counter()
        for row in eligible[kind].values():
            count = int(row["layout_count"])
            upper = next(upper for upper in (40, 400, 4000) if count <= upper)
            bin_key = row["seed"], upper
            if control_counts[bin_key] < controls_per_bin:
                selected.append(row)
                control_counts[bin_key] += 1

    return {
        "primary": eligible["primary"].values(),
        "isolated": isolated,
        **controls,
    }


def main():
    parser = argparse.ArgumentParser(description="Verify raw Hill audit observations and select study cohorts")
    parser.add_argument("states", type=Path, nargs="+")
    parser.add_argument("--out-prefix", type=Path, required=True)
    parser.add_argument("--controls-per-bin", type=int, default=4)
    parser.add_argument("--isolated-per-seed", type=int, default=25)
    args = parser.parse_args()
    fields, rows = read_and_verify(args.states)
    print("Raw BF status by seed:")
    for (seed, status), count in sorted(Counter((row["seed"], row["whole_bf_status"]) for row in rows).items()):
        print(f"  {seed} {status} {count}")
    groups = select(rows, args.controls_per_bin, args.isolated_per_seed)
    for kind, selected in groups.items():
        output = args.out_prefix.with_name(f"{args.out_prefix.name}-{kind}.tsv")
        with output.open("w", encoding="utf8", newline="") as stream:
            writer = csv.DictWriter(stream, delimiter="\t", fieldnames=fields)
            writer.writeheader()
            writer.writerows(selected)
        print(f"{output.name}: {len(selected)}")
        for (seed, status), count in sorted(Counter((row["seed"], row["whole_bf_status"]) for row in selected).items()):
            print(f"  {seed} {status} {count}")


if __name__ == "__main__":
    main()
