#include <algorithm>
#include <array>
#include <charconv>
#include <cstddef>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <numeric>
#include <span>
#include <stdexcept>
#include <string>
#include <string_view>
#include <unordered_map>
#include <vector>

namespace {
constexpr int Clues = 9;
constexpr std::uint8_t Mine = 9;
constexpr int MaxCells = 480;
constexpr int MaxWorlds = 65'536;
constexpr std::uint32_t DefaultNodeLimit = 350'000;

using World = std::uint16_t;
using Column = std::uint16_t;
using Belief = std::span<const World>;
using Columns = std::span<const Column>;

struct Matrix {
    int cells = 0;
    int worlds = 0;
    std::array<int, 3> requested{};
    std::vector<std::uint8_t> observations;
    std::vector<World> layout_class;
    bool duplicate_layouts = false;

    const std::uint8_t *column(Column i) const
    {
        return observations.data() + static_cast<std::size_t>(i) * worlds;
    }
};

Matrix ReadMatrix(std::istream &input)
{
    Matrix result;
    if (!(input >> result.worlds >> result.cells >> result.requested[0] >>
          result.requested[1] >> result.requested[2]))
        throw std::runtime_error("expected worldCount columnCount hillColumn edColumn safestColumn");
    if (result.cells < 1 || result.cells > MaxCells ||
        result.worlds < 1 || result.worlds > MaxWorlds)
        throw std::runtime_error("matrix dimensions exceed the supported range");
    for (int i : result.requested)
        if (i < -1 || i >= result.cells)
            throw std::runtime_error("requested column outside the matrix");

    result.observations.resize(static_cast<std::size_t>(result.cells) * result.worlds);
    std::string row;
    for (int c = 0; c < result.cells; ++c) {
        if (!(input >> row) || row.size() != static_cast<std::size_t>(result.worlds))
            throw std::runtime_error("observation column missing or wrong length");
        auto *obs = result.observations.data() + static_cast<std::size_t>(c) * result.worlds;
        for (int w = 0; w < result.worlds; ++w) {
            const char glyph = row[w];
            if (glyph != 'M' && (glyph < '0' || glyph > '8'))
                throw std::runtime_error("observations must be M or a clue from 0 to 8");
            obs[w] = glyph == 'M' ? Mine : static_cast<std::uint8_t>(glyph - '0');
        }
    }
    if (input >> row)
        throw std::runtime_error("extra data after the observation matrix");

    result.layout_class.resize(result.worlds);
    std::unordered_map<std::string, World> layouts;
    layouts.reserve(result.worlds);
    std::string mine_pattern((result.cells + 7) / 8, '\0');
    int required_mines = -1;
    for (int w = 0; w < result.worlds; ++w) {
        std::fill(mine_pattern.begin(), mine_pattern.end(), '\0');
        int count = 0;
        for (int c = 0; c < result.cells; ++c) {
            if (result.column(static_cast<Column>(c))[w] == Mine) {
                mine_pattern[c / 8] |= 1 << (c % 8);
                ++count;
            }
        }
        if (w == 0)
            required_mines = count;
        else if (count != required_mines)
            throw std::runtime_error("all worlds must have the same remaining mine count");
        auto [entry, is_new] = layouts.try_emplace(mine_pattern, static_cast<World>(w));
        result.layout_class[w] = entry->second;
        result.duplicate_layouts |= !is_new;
    }
    return result;
}

struct BeliefHash {
    using is_transparent = void;

    std::size_t operator()(Belief belief) const noexcept
    {
        std::uint64_t hash = 0xcbf29ce484222325ULL;
        for (World world : belief)
            hash = (hash ^ world) * 0x100000001b3ULL;
        return static_cast<std::size_t>(hash);
    }
};

struct BeliefEqual {
    using is_transparent = void;

    bool operator()(Belief lhs, Belief rhs) const noexcept
    {
        return std::equal(lhs.begin(), lhs.end(), rhs.begin(), rhs.end());
    }
};

struct Action {
    Column column;
    int survivors;
    int outcomes;
    std::array<int, Clues> counts;
};


} // namespace
