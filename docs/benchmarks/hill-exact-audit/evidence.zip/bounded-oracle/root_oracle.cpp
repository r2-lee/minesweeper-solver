#include "matrix.hpp"

namespace {
struct Span {
    int lo;
    int hi;
    bool greedy = false;
    bool exact() const { return lo == hi; }
};

struct Exhausted {};

class BoundedSolver {
public:
    BoundedSolver(const Matrix &matrix, std::uint32_t cap)
        : matrix_(matrix), cap_(cap), all_columns_(matrix.cells)
    {
        if (matrix.duplicate_layouts)
            throw std::runtime_error("bounds oracle requires distinct mine layouts");
        std::iota(all_columns_.begin(), all_columns_.end(), 0);
        memo_.reserve(std::min<std::uint32_t>(cap, 131'072));
    }

    Span known(Belief belief) const
    {
        if (belief.size() <= 1)
            return {static_cast<int>(belief.size()), static_cast<int>(belief.size()), true};
        const auto found = memo_.find(belief);
        return found == memo_.end() ? Span{1, static_cast<int>(belief.size())} : found->second;
    }

    Span greedy(Belief belief, Columns columns, int depth = 0)
    {
        Span previous = known(belief);
        if (previous.exact() || previous.greedy)
            return previous;
        ++greedy_nodes_;
        auto &frame = frames_[depth];
        fill(belief, columns, frame.actions);
        if (frame.actions.empty())
            return save(belief, {1, 1, true}, previous);
        const Action &action = frame.actions.front();
        auto groups = partition(belief, action, frame);
        Span outcome{0, 0, true};
        for (Belief group : groups) {
            if (group.empty())
                continue;
            Span child = greedy(group, columns, depth + 1);
            outcome.lo += child.lo;
            outcome.hi += child.hi;
        }
        if (action.survivors < static_cast<int>(belief.size()))
            outcome.hi = action.survivors;
        return save(belief, outcome, previous);
    }

    Span exact_or_limit(Belief belief, int cut = 0)
    {
        try {
            return search(belief, all_columns_, cut, 0);
        } catch (const Exhausted &) {
            return known(belief);
        }
    }

    Span initial(Belief belief) { return greedy(belief, all_columns_); }
    std::uint32_t nodes() const { return nodes_; }
    std::uint32_t greedy_nodes() const { return greedy_nodes_; }

private:
    struct Frame {
        std::vector<Action> actions;
        std::vector<Column> active;
        std::vector<Column> explored;
        std::vector<World> partitions;
    };

    Span save(Belief belief, Span value, Span previous)
    {
        value.lo = std::max(value.lo, previous.lo);
        value.hi = std::min(value.hi, previous.hi);
        value.greedy = value.greedy || previous.greedy;
        if (value.lo > value.hi)
            throw std::logic_error("inconsistent exact search bounds");
        auto existing = memo_.find(belief);
        if (existing != memo_.end()) {
            existing->second = value;
        } else {
            memo_.emplace(std::vector<World>(belief.begin(), belief.end()), value);
        }
        return value;
    }

    void fill(Belief belief, Columns columns, std::vector<Action> &actions)
    {
        const int total = static_cast<int>(belief.size());
        actions.clear();
        for (const Column cell : columns) {
            std::array<int, Clues + 1> counts{};
            const auto *obs = matrix_.column(cell);
            for (World world : belief)
                ++counts[obs[world]];
            const int alive = total - counts[Mine];
            if (alive <= 1)
                continue;
            Action action{cell, alive, 0, {}};
            for (int clue = 0; clue < Clues; ++clue) {
                action.counts[clue] = counts[clue];
                action.outcomes += counts[clue] != 0;
            }
            if (action.outcomes < 2)
                continue;
            if (alive == total) {
                actions.clear();
                actions.push_back(action);
                return;
            }
            actions.push_back(action);
        }
        std::sort(actions.begin(), actions.end(), [](const Action &a, const Action &b) {
            if (a.survivors != b.survivors)
                return a.survivors > b.survivors;
            if (a.outcomes != b.outcomes)
                return a.outcomes > b.outcomes;
            return a.column < b.column;
        });
    }

    std::array<Belief, Clues> partition(Belief belief, const Action &action, Frame &frame)
    {
        auto &out = frame.partitions;
        out.resize(action.survivors);
        std::array<int, Clues> offset{};
        for (int clue = 1; clue < Clues; ++clue)
            offset[clue] = offset[clue - 1] + action.counts[clue - 1];
        auto next = offset;
        const auto *obs = matrix_.column(action.column);
        for (World world : belief) {
            const int clue = obs[world];
            if (clue < Clues)
                out[next[clue]++] = world;
        }
        std::array<Belief, Clues> groups;
        for (int clue = 0; clue < Clues; ++clue)
            groups[clue] = Belief(out.data() + offset[clue], action.counts[clue]);
        return groups;
    }

    bool dominated(Belief belief, Column cell, Columns seen) const
    {
        const auto *obs = matrix_.column(cell);
        for (Column earlier : seen) {
            const auto *other = matrix_.column(earlier);
            bool subset = true;
            for (World world : belief) {
                if (obs[world] != Mine && other[world] == Mine) {
                    subset = false;
                    break;
                }
            }
            if (subset)
                return true;
        }
        return false;
    }

    Span score(Belief belief, const Action &action, Columns columns, int cut, int depth)
    {
        auto groups = partition(belief, action, frames_[depth]);
        std::sort(groups.begin(), groups.end(), [](Belief a, Belief b) { return a.size() > b.size(); });
        std::array<Span, Clues> prior;
        int lo = 0;
        int hi = 0;
        for (std::size_t i = 0; i < groups.size(); ++i) {
            prior[i] = known(groups[i]);
            lo += prior[i].lo;
            hi += prior[i].hi;
        }
        for (std::size_t i = 0; i < groups.size() && hi > cut; ++i) {
            if (prior[i].exact())
                continue;
            Span child = search(groups[i], columns, cut - (hi - prior[i].hi), depth + 1);
            lo += child.lo - prior[i].lo;
            hi += child.hi - prior[i].hi;
        }
        return {lo, hi};
    }

    Span search(Belief belief, Columns columns, int cut, int depth)
    {
        Span previous = known(belief);
        if (previous.exact() || previous.hi <= cut)
            return previous;
        if (nodes_ == cap_)
            throw Exhausted{};
        ++nodes_;
        auto &frame = frames_[depth];
        fill(belief, columns, frame.actions);
        if (frame.actions.empty())
            return save(belief, {1, 1}, previous);

        const Action &first = frame.actions.front();
        if (first.survivors == static_cast<int>(belief.size()))
            return save(belief, score(belief, first, columns, cut, depth), previous);

        frame.active.clear();
        frame.explored.clear();
        for (const Action &action : frame.actions)
            frame.active.push_back(action.column);

        int best = previous.lo;
        int upper = previous.lo;
        for (const Action &action : frame.actions) {
            const int threshold = std::max(cut, best);
            if (action.survivors <= threshold) {
                upper = std::max(upper, action.survivors);
                break;
            }
            if (dominated(belief, action.column, frame.explored))
                continue;
            frame.explored.push_back(action.column);
            Span candidate = score(belief, action, frame.active, threshold, depth);
            best = std::max(best, candidate.lo);
            upper = std::max(upper, candidate.hi);
            if (best == previous.hi)
                return save(belief, {best, best}, previous);
        }
        return save(belief, {best, std::max(upper, best)}, previous);
    }

    const Matrix &matrix_;
    std::uint32_t cap_;
    std::uint32_t nodes_ = 0;
    std::uint32_t greedy_nodes_ = 0;
    std::vector<Column> all_columns_;
    std::array<Frame, MaxCells + 1> frames_;
    std::unordered_map<std::vector<World>, Span, BeliefHash, BeliefEqual> memo_;
};

std::vector<World> survivors(const Matrix &matrix, const std::vector<World> &all, int column)
{
    if (column < 0)
        return {};
    std::vector<World> result;
    const auto *obs = matrix.column(static_cast<Column>(column));
    for (World world : all) {
        if (obs[world] != Mine)
            result.push_back(world);
    }
    return result;
}
} // namespace

namespace {
struct Option {
    int col;
    std::vector<World> set;
    Span score;
};

std::vector<Option> choices(const Matrix &matrix, const std::vector<World> &all)
{
    std::vector<Option> result;
    for (int col = 0; col < matrix.cells; ++col) {
        const auto *obs = matrix.column(static_cast<Column>(col));
        int digits = 0;
        for (World world : all) {
            if (obs[world] < Clues)
                digits |= 1 << obs[world];
        }
        if ((digits & (digits - 1)) == 0)
            continue;
        auto safe = survivors(matrix, all, col);
        if (safe == all) {
            result.clear();
            result.push_back({col, std::move(safe), {1, matrix.worlds}});
            return result;
        }
        result.push_back({col, std::move(safe), {1, matrix.worlds}});
    }
    std::sort(result.begin(), result.end(), [](const Option &a, const Option &b) {
        if (a.set.size() != b.set.size())
            return a.set.size() > b.set.size();
        return a.col < b.col;
    });
    std::vector<Option> minimal;
    for (auto &option : result) {
        if (std::none_of(minimal.begin(), minimal.end(), [&](const Option &other) {
                return std::includes(other.set.begin(), other.set.end(),
                                     option.set.begin(), option.set.end());
            }))
            minimal.push_back(std::move(option));
    }
    return minimal;
}
} // namespace

int main(int argc, char **argv)
{
    try {
        if (argc != 3)
            throw std::runtime_error("usage: root_oracle.exe MATRIX NODE_LIMIT");
        std::uint32_t cap = static_cast<std::uint32_t>(std::stoul(argv[2]));
        std::ifstream input(argv[1]);
        Matrix matrix = ReadMatrix(input);
        std::vector<World> all(matrix.worlds);
        std::iota(all.begin(), all.end(), 0);
        auto actions = choices(matrix, all);
        std::array<std::vector<World>, 3> selected;
        BoundedSolver solver(matrix, cap);
        std::array<int, 3> quick_selected{};
        for (std::size_t i = 0; i < selected.size(); ++i) {
            selected[i] = survivors(matrix, all, matrix.requested[i]);
            quick_selected[i] = solver.initial(selected[i]).lo;
        }
        int best = 1;
        int witness = -1;
        for (auto &action : actions) {
            action.score = solver.initial(action.set);
            if (action.score.lo > best || witness < 0) {
                best = action.score.lo;
                witness = action.col;
            }
        }
        int quick_best = best;
        std::sort(actions.begin(), actions.end(), [](const Option &a, const Option &b) {
            if (a.score.lo != b.score.lo)
                return a.score.lo > b.score.lo;
            if (a.score.hi != b.score.hi)
                return a.score.hi < b.score.hi;
            return a.col < b.col;
        });
        int upper = best;
        for (auto &action : actions) {
            action.score = solver.known(action.set);
            if (action.score.hi > best)
                action.score = solver.exact_or_limit(action.set, best);
            if (action.score.lo > best) {
                best = action.score.lo;
                witness = action.col;
            }
            upper = std::max(upper, action.score.hi);
        }
        std::array<Span, 4> scores;
        for (std::size_t i = 0; i < selected.size(); ++i)
            scores[i + 1] = solver.exact_or_limit(selected[i]);
        upper = best;
        for (auto &action : actions) {
            action.score = solver.known(action.set);
            if (action.score.lo > best) {
                best = action.score.lo;
                witness = action.col;
            }
            upper = std::max(upper, action.score.hi);
        }
        for (std::size_t i = 1; i < scores.size(); ++i) {
            if (scores[i].lo > best) {
                best = scores[i].lo;
                witness = matrix.requested[i - 1];
            }
        }
        scores[0] = {best, std::max(best, upper)};
        for (std::size_t i = 1; i < scores.size(); ++i)
            scores[i].hi = std::min(scores[i].hi, scores[0].hi);
        bool exact = true;
        for (const Span score : scores) {
            if (score.lo > score.hi)
                throw std::logic_error("invalid root bounds");
            exact &= score.exact();
        }
        std::cout << (exact ? "exact" : "partial");
        for (const Span score : scores)
            std::cout << '\t' << score.lo << '\t' << score.hi;
        std::cout << '\t' << solver.nodes() << '\t' << solver.greedy_nodes()
                  << '\t' << witness << '\t' << quick_best;
        for (int value : quick_selected)
            std::cout << '\t' << value;
        std::cout << '\t' << actions.size() << '\n';
    } catch (const std::exception &err) {
        std::cerr << err.what() << '\n';
        return 2;
    }
}
