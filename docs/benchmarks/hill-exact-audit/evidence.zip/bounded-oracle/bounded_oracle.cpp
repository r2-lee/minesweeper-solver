#include "matrix.hpp"

namespace {
struct Span {
    int lo;
    int hi;
    bool greedy = false;
    bool exact() const { return lo == hi; }
};

struct Exhausted {};

class BoundedSolver {
public:
    BoundedSolver(const Matrix &matrix, std::uint32_t cap)
        : matrix_(matrix), cap_(cap), all_columns_(matrix.cells)
    {
        if (matrix.duplicate_layouts)
            throw std::runtime_error("bounds oracle requires distinct mine layouts");
        std::iota(all_columns_.begin(), all_columns_.end(), 0);
        memo_.reserve(std::min<std::uint32_t>(cap, 131'072));
    }

    Span known(Belief belief) const
    {
        if (belief.size() <= 1)
            return {static_cast<int>(belief.size()), static_cast<int>(belief.size()), true};
        const auto found = memo_.find(belief);
        return found == memo_.end() ? Span{1, static_cast<int>(belief.size())} : found->second;
    }

    Span greedy(Belief belief, Columns columns, int depth = 0)
    {
        Span previous = known(belief);
        if (previous.exact() || previous.greedy)
            return previous;
        ++greedy_nodes_;
        auto &frame = frames_[depth];
        fill(belief, columns, frame.actions);
        if (frame.actions.empty())
            return save(belief, {1, 1, true}, previous);
        const Action &action = frame.actions.front();
        auto groups = partition(belief, action, frame);
        Span outcome{0, 0, true};
        for (Belief group : groups) {
            if (group.empty())
                continue;
            Span child = greedy(group, columns, depth + 1);
            outcome.lo += child.lo;
            outcome.hi += child.hi;
        }
        if (action.survivors < static_cast<int>(belief.size()))
            outcome.hi = action.survivors;
        return save(belief, outcome, previous);
    }

    Span exact_or_limit(Belief belief)
    {
        try {
            return search(belief, all_columns_, 0, 0);
        } catch (const Exhausted &) {
            return known(belief);
        }
    }

    Span initial(Belief belief) { return greedy(belief, all_columns_); }
    std::uint32_t nodes() const { return nodes_; }
    std::uint32_t greedy_nodes() const { return greedy_nodes_; }

private:
    struct Frame {
        std::vector<Action> actions;
        std::vector<Column> active;
        std::vector<Column> explored;
        std::vector<World> partitions;
    };

    Span save(Belief belief, Span value, Span previous)
    {
        value.lo = std::max(value.lo, previous.lo);
        value.hi = std::min(value.hi, previous.hi);
        value.greedy = value.greedy || previous.greedy;
        if (value.lo > value.hi)
            throw std::logic_error("inconsistent exact search bounds");
        auto existing = memo_.find(belief);
        if (existing != memo_.end()) {
            existing->second = value;
        } else {
            memo_.emplace(std::vector<World>(belief.begin(), belief.end()), value);
        }
        return value;
    }

    void fill(Belief belief, Columns columns, std::vector<Action> &actions)
    {
        const int total = static_cast<int>(belief.size());
        actions.clear();
        for (const Column cell : columns) {
            std::array<int, Clues + 1> counts{};
            const auto *obs = matrix_.column(cell);
            for (World world : belief)
                ++counts[obs[world]];
            const int alive = total - counts[Mine];
            if (alive <= 1)
                continue;
            Action action{cell, alive, 0, {}};
            for (int clue = 0; clue < Clues; ++clue) {
                action.counts[clue] = counts[clue];
                action.outcomes += counts[clue] != 0;
            }
            if (action.outcomes < 2)
                continue;
            if (alive == total) {
                actions.clear();
                actions.push_back(action);
                return;
            }
            actions.push_back(action);
        }
        std::sort(actions.begin(), actions.end(), [](const Action &a, const Action &b) {
            if (a.survivors != b.survivors)
                return a.survivors > b.survivors;
            if (a.outcomes != b.outcomes)
                return a.outcomes > b.outcomes;
            return a.column < b.column;
        });
    }

    std::array<Belief, Clues> partition(Belief belief, const Action &action, Frame &frame)
    {
        auto &out = frame.partitions;
        out.resize(action.survivors);
        std::array<int, Clues> offset{};
        for (int clue = 1; clue < Clues; ++clue)
            offset[clue] = offset[clue - 1] + action.counts[clue - 1];
        auto next = offset;
        const auto *obs = matrix_.column(action.column);
        for (World world : belief) {
            const int clue = obs[world];
            if (clue < Clues)
                out[next[clue]++] = world;
        }
        std::array<Belief, Clues> groups;
        for (int clue = 0; clue < Clues; ++clue)
            groups[clue] = Belief(out.data() + offset[clue], action.counts[clue]);
        return groups;
    }

    bool dominated(Belief belief, Column cell, Columns seen) const
    {
        const auto *obs = matrix_.column(cell);
        for (Column earlier : seen) {
            const auto *other = matrix_.column(earlier);
            bool subset = true;
            for (World world : belief) {
                if (obs[world] != Mine && other[world] == Mine) {
                    subset = false;
                    break;
                }
            }
            if (subset)
                return true;
        }
        return false;
    }

    Span score(Belief belief, const Action &action, Columns columns, int cut, int depth)
    {
        auto groups = partition(belief, action, frames_[depth]);
        std::sort(groups.begin(), groups.end(), [](Belief a, Belief b) { return a.size() > b.size(); });
        std::array<Span, Clues> prior;
        int lo = 0;
        int hi = 0;
        for (std::size_t i = 0; i < groups.size(); ++i) {
            prior[i] = known(groups[i]);
            lo += prior[i].lo;
            hi += prior[i].hi;
        }
        for (std::size_t i = 0; i < groups.size() && hi > cut; ++i) {
            if (prior[i].exact())
                continue;
            Span child = search(groups[i], columns, cut - (hi - prior[i].hi), depth + 1);
            lo += child.lo - prior[i].lo;
            hi += child.hi - prior[i].hi;
        }
        return {lo, hi};
    }

    Span search(Belief belief, Columns columns, int cut, int depth)
    {
        Span previous = known(belief);
        if (previous.exact() || previous.hi <= cut)
            return previous;
        if (nodes_ == cap_)
            throw Exhausted{};
        ++nodes_;
        auto &frame = frames_[depth];
        fill(belief, columns, frame.actions);
        if (frame.actions.empty())
            return save(belief, {1, 1}, previous);

        const Action &first = frame.actions.front();
        if (first.survivors == static_cast<int>(belief.size()))
            return save(belief, score(belief, first, columns, cut, depth), previous);

        frame.active.clear();
        frame.explored.clear();
        for (const Action &action : frame.actions)
            frame.active.push_back(action.column);

        int best = previous.lo;
        int upper = previous.lo;
        for (const Action &action : frame.actions) {
            const int threshold = std::max(cut, best);
            if (action.survivors <= threshold) {
                upper = std::max(upper, action.survivors);
                break;
            }
            if (dominated(belief, action.column, frame.explored))
                continue;
            frame.explored.push_back(action.column);
            Span candidate = score(belief, action, frame.active, threshold, depth);
            best = std::max(best, candidate.lo);
            upper = std::max(upper, candidate.hi);
            if (best == previous.hi)
                return save(belief, {best, best}, previous);
        }
        return save(belief, {best, std::max(upper, best)}, previous);
    }

    const Matrix &matrix_;
    std::uint32_t cap_;
    std::uint32_t nodes_ = 0;
    std::uint32_t greedy_nodes_ = 0;
    std::vector<Column> all_columns_;
    std::array<Frame, MaxCells + 1> frames_;
    std::unordered_map<std::vector<World>, Span, BeliefHash, BeliefEqual> memo_;
};

std::vector<World> survivors(const Matrix &matrix, const std::vector<World> &all, int column)
{
    if (column < 0)
        return {};
    std::vector<World> result;
    const auto *obs = matrix.column(static_cast<Column>(column));
    for (World world : all) {
        if (obs[world] != Mine)
            result.push_back(world);
    }
    return result;
}
} // namespace

int main(int argc, char **argv)
{
    try {
        if (argc < 2 || argc > 3)
            throw std::runtime_error("usage: bounded_oracle.exe MATRIX [NODE_LIMIT]");
        auto cap = DefaultNodeLimit;
        if (argc == 3)
            cap = static_cast<std::uint32_t>(std::stoul(argv[2]));
        std::ifstream input(argv[1]);
        Matrix matrix = ReadMatrix(input);
        std::array<std::vector<World>, 4> beliefs;
        beliefs[0].resize(matrix.worlds);
        std::iota(beliefs[0].begin(), beliefs[0].end(), 0);
        for (std::size_t i = 1; i < beliefs.size(); ++i)
            beliefs[i] = survivors(matrix, beliefs[0], matrix.requested[i - 1]);

        BoundedSolver solver(matrix, cap);
        std::array<Span, 4> bounds;
        for (std::size_t i = 0; i < beliefs.size(); ++i)
            bounds[i] = solver.initial(beliefs[i]);
        for (std::size_t i = 0; i < beliefs.size(); ++i)
            bounds[i] = solver.exact_or_limit(beliefs[i]);
        for (std::size_t i = 0; i < beliefs.size(); ++i)
            bounds[i] = solver.known(beliefs[i]);
        for (std::size_t i = 1; i < bounds.size(); ++i) {
            bounds[0].lo = std::max(bounds[0].lo, bounds[i].lo);
            bounds[i].hi = std::min(bounds[i].hi, bounds[0].hi);
        }
        bool exact = true;
        for (const Span bound : bounds) {
            if (bound.lo > bound.hi)
                throw std::logic_error("invalid result bounds");
            exact &= bound.exact();
        }
        std::cout << (exact ? "exact" : "partial");
        for (const Span bound : bounds)
            std::cout << '\t' << bound.lo << '\t' << bound.hi;
        std::cout << '\t' << solver.nodes() << '\t' << solver.greedy_nodes() << '\n';
    } catch (const std::exception &err) {
        std::cerr << err.what() << '\n';
        return 2;
    }
}
