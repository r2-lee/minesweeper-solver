#include <algorithm>
#include <array>
#include <charconv>
#include <cstddef>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <numeric>
#include <span>
#include <stdexcept>
#include <string>
#include <string_view>
#include <unordered_map>
#include <vector>

namespace {
constexpr int Clues = 9;
constexpr std::uint8_t Mine = 9;
constexpr int MaxCells = 480;
constexpr int MaxWorlds = 65'536;
constexpr std::uint32_t DefaultNodeLimit = 350'000;

using World = std::uint16_t;
using Column = std::uint16_t;
using Belief = std::span<const World>;
using Columns = std::span<const Column>;

struct Matrix {
    int cells = 0;
    int worlds = 0;
    std::array<int, 3> requested{};
    std::vector<std::uint8_t> observations;
    std::vector<World> layout_class;
    bool duplicate_layouts = false;

    const std::uint8_t *column(Column i) const
    {
        return observations.data() + static_cast<std::size_t>(i) * worlds;
    }
};

Matrix ReadMatrix(std::istream &input)
{
    Matrix result;
    if (!(input >> result.worlds >> result.cells >> result.requested[0] >>
          result.requested[1] >> result.requested[2]))
        throw std::runtime_error("expected worldCount columnCount hillColumn edColumn safestColumn");
    if (result.cells < 1 || result.cells > MaxCells ||
        result.worlds < 1 || result.worlds > MaxWorlds)
        throw std::runtime_error("matrix dimensions exceed the supported range");
    for (int i : result.requested)
        if (i < -1 || i >= result.cells)
            throw std::runtime_error("requested column outside the matrix");

    result.observations.resize(static_cast<std::size_t>(result.cells) * result.worlds);
    std::string row;
    for (int c = 0; c < result.cells; ++c) {
        if (!(input >> row) || row.size() != static_cast<std::size_t>(result.worlds))
            throw std::runtime_error("observation column missing or wrong length");
        auto *obs = result.observations.data() + static_cast<std::size_t>(c) * result.worlds;
        for (int w = 0; w < result.worlds; ++w) {
            const char glyph = row[w];
            if (glyph != 'M' && (glyph < '0' || glyph > '8'))
                throw std::runtime_error("observations must be M or a clue from 0 to 8");
            obs[w] = glyph == 'M' ? Mine : static_cast<std::uint8_t>(glyph - '0');
        }
    }
    if (input >> row)
        throw std::runtime_error("extra data after the observation matrix");

    result.layout_class.resize(result.worlds);
    std::unordered_map<std::string, World> layouts;
    layouts.reserve(result.worlds);
    std::string mine_pattern((result.cells + 7) / 8, '\0');
    int required_mines = -1;
    for (int w = 0; w < result.worlds; ++w) {
        std::fill(mine_pattern.begin(), mine_pattern.end(), '\0');
        int count = 0;
        for (int c = 0; c < result.cells; ++c) {
            if (result.column(static_cast<Column>(c))[w] == Mine) {
                mine_pattern[c / 8] |= 1 << (c % 8);
                ++count;
            }
        }
        if (w == 0)
            required_mines = count;
        else if (count != required_mines)
            throw std::runtime_error("all worlds must have the same remaining mine count");
        auto [entry, is_new] = layouts.try_emplace(mine_pattern, static_cast<World>(w));
        result.layout_class[w] = entry->second;
        result.duplicate_layouts |= !is_new;
    }
    return result;
}

struct BeliefHash {
    using is_transparent = void;

    std::size_t operator()(Belief belief) const noexcept
    {
        std::uint64_t hash = 0xcbf29ce484222325ULL;
        for (World world : belief)
            hash = (hash ^ world) * 0x100000001b3ULL;
        return static_cast<std::size_t>(hash);
    }
};

struct BeliefEqual {
    using is_transparent = void;

    bool operator()(Belief lhs, Belief rhs) const noexcept
    {
        return std::equal(lhs.begin(), lhs.end(), rhs.begin(), rhs.end());
    }
};

struct Action {
    Column column;
    int survivors;
    int outcomes;
    std::array<int, Clues> counts;
};

struct BudgetExhausted {};

class Solver {
public:
    Solver(const Matrix &matrix, std::uint32_t limit) : matrix_(matrix), limit_(limit)
    {
        root_.resize(matrix.worlds);
        std::iota(root_.begin(), root_.end(), 0);
        columns_.resize(matrix.cells);
        std::iota(columns_.begin(), columns_.end(), 0);
        memo_.reserve(std::min<std::uint32_t>(limit, 65'536));
    }

    int optimal()
    {
        return value(root_, columns_);
    }

    int forced(int cell)
    {
        if (cell < 0)
            return -1;
        std::vector<World> survivors;
        survivors.reserve(root_.size());
        const auto *obs = matrix_.column(static_cast<Column>(cell));
        for (World world : root_)
            if (obs[world] != Mine)
                survivors.push_back(world);
        return value(survivors, columns_);
    }

    std::uint32_t nodes() const { return nodes_; }

private:
    struct Frame {
        std::vector<Action> actions;
        std::vector<Column> active;
        std::vector<Column> explored;
        std::vector<World> partitions;
    };

    int dead_value(Belief belief) const
    {
        if (!matrix_.duplicate_layouts)
            return 1;
        std::unordered_map<World, int> counts;
        int best = 0;
        for (World world : belief)
            best = std::max(best, ++counts[matrix_.layout_class[world]]);
        return best;
    }

    bool dominated(Belief belief, Column c, Columns earlier) const
    {
        const auto *obs = matrix_.column(c);
        for (Column d : earlier) {
            const auto *other = matrix_.column(d);
            bool subset = true;
            for (World world : belief) {
                if (obs[world] != Mine && other[world] == Mine) {
                    subset = false;
                    break;
                }
            }
            if (subset)
                return true;
        }
        return false;
    }

    int score(Belief belief, const Action &action, Columns candidates, int best, int depth)
    {
        auto &out = frames_[depth].partitions;
        out.resize(action.survivors);
        std::array<int, Clues> offset{};
        for (int clue = 1; clue < Clues; ++clue)
            offset[clue] = offset[clue - 1] + action.counts[clue - 1];
        auto next = offset;
        const auto *obs = matrix_.column(action.column);
        for (World world : belief) {
            int code = obs[world];
            if (code < Clues)
                out[next[code]++] = world;
        }

        std::array<int, Clues> order{};
        int branches = 0;
        for (int clue = 0; clue < Clues; ++clue)
            if (action.counts[clue] > 1)
                order[branches++] = clue;
        std::sort(order.begin(), order.begin() + branches,
                  [&action](int a, int b) { return action.counts[a] > action.counts[b]; });

        int upper = action.survivors;
        for (int i = 0; i < branches; ++i) {
            int clue = order[i];
            int size = action.counts[clue];
            const Belief group(out.data() + offset[clue], size);
            upper -= size - value(group, candidates, depth + 1);
            if (upper <= best)
                break;
        }
        return upper;
    }

    int value(Belief belief, Columns candidates, int depth = 0)
    {
        int total = static_cast<int>(belief.size());
        if (total <= 1)
            return total;
        if (auto cached = memo_.find(belief); cached != memo_.end())
            return cached->second;
        if (nodes_ == limit_)
            throw BudgetExhausted{};
        ++nodes_;

        Frame &frame = frames_[depth];
        auto &actions = frame.actions;
        actions.clear();
        for (Column cell : candidates) {
            std::array<int, Clues + 1> counts{};
            const auto *obs = matrix_.column(cell);
            for (World world : belief)
                ++counts[obs[world]];
            int alive = total - counts[Mine];
            if (alive <= 1)
                continue;

            Action action{cell, alive, 0, {}};
            for (int clue = 0; clue < Clues; ++clue) {
                action.counts[clue] = counts[clue];
                action.outcomes += counts[clue] != 0;
            }
            if (action.outcomes < 2)
                continue;
            // A certain safe observation can precede every candidate policy.
            if (alive == total) {
                int exact = score(belief, action, candidates, 0, depth);
                return remember(belief, exact);
            }
            actions.push_back(action);
        }

        if (actions.empty())
            return remember(belief, dead_value(belief));

        std::sort(actions.begin(), actions.end(), [](const Action &a, const Action &b) {
            if (a.survivors != b.survivors)
                return a.survivors > b.survivors;
            if (a.outcomes != b.outcomes)
                return a.outcomes > b.outcomes;
            return a.column < b.column;
        });
        frame.active.clear();
        frame.explored.clear();
        for (const Action &action : actions)
            frame.active.push_back(action.column);

        int best = dead_value(belief);
        for (const Action &action : actions) {
            if (action.survivors <= best)
                break;
            if (dominated(belief, action.column, frame.explored))
                continue;
            frame.explored.push_back(action.column);
            const int bound = score(belief, action, frame.active, best, depth);
            best = std::max(best, bound);
        }
        return remember(belief, best);
    }

    int remember(Belief belief, int value)
    {
        memo_.emplace(std::vector<World>(belief.begin(), belief.end()), value);
        return value;
    }

    const Matrix &matrix_;
    std::uint32_t limit_;
    std::uint32_t nodes_ = 0;
    std::vector<World> root_;
    std::vector<Column> columns_;
    std::array<Frame, MaxCells + 1> frames_;
    std::unordered_map<std::vector<World>, int, BeliefHash, BeliefEqual> memo_;
};
}  // namespace

int main(int argc, char **argv)
{
    if (argc < 2 || argc > 3) {
        std::cerr << "Usage: native_oracle.exe <matrix.txt|-> [node_limit]\n";
        return 2;
    }
    std::uint32_t node_limit = DefaultNodeLimit;
    if (argc == 3) {
        const std::string_view text = argv[2];
        const char *end = text.data() + text.size();
        const auto parsed = std::from_chars(text.data(), end, node_limit);
        if (parsed.ec != std::errc{} || parsed.ptr != end || node_limit == 0) {
            std::cerr << "node_limit must be a positive integer\n";
            return 2;
        }
    }

    try {
        std::ifstream file;
        if (std::string_view(argv[1]) != "-") {
            file.open(argv[1]);
            if (!file)
                throw std::runtime_error("failed to open the observation matrix");
        }
        const Matrix matrix = ReadMatrix(file.is_open() ? file : std::cin);
        Solver solver(matrix, node_limit);
        try {
            const int optimum = solver.optimal();
            std::array<int, 3> forced{};
            for (std::size_t i = 0; i < forced.size(); ++i) {
                forced[i] = solver.forced(matrix.requested[i]);
                if (forced[i] > optimum)
                    throw std::logic_error("forced first move exceeds the unrestricted optimum");
            }
            std::cout << "exact\t" << optimum;
            for (int answer : forced) {
                std::cout << '\t';
                if (answer < 0)
                    std::cout << "NA";
                else
                    std::cout << answer;
            }
            std::cout << '\t' << solver.nodes() << '\n';
        } catch (const BudgetExhausted &) {
            std::cout << "budget\tNA\tNA\tNA\tNA\t" << solver.nodes() << '\n';
            return 0;
        }
    } catch (const std::exception &error) {
        std::cerr << error.what() << '\n';
        return 2;
    }
}

