from collections import defaultdict
from functools import cache
from itertools import combinations
import random

from exact_oracle import enumerate_layouts, make_tree


def reference(state, rows, cols, mine_count):
    def adjacent(i, j):
        return i != j and max(abs(i // cols - j // cols), abs(i % cols - j % cols)) == 1

    cells = tuple(range(rows * cols))
    unknown = tuple(i for i in cells if state[i] == "H")
    flagged = {i for i in cells if state[i] == "M"}
    seen = frozenset(i for i in cells if state[i].isdigit())
    all_numbers = []
    worlds = []
    for extra in combinations(unknown, mine_count - len(flagged)):
        mines = frozenset(extra) | flagged
        clues = tuple(sum(adjacent(i, j) for j in mines) for i in cells)
        if all(clues[i] == int(state[i]) for i in seen):
            all_numbers.append(clues)
            worlds.append(mines)

    def action(belief, opened, tile):
        branches = defaultdict(list)
        for index in belief:
            if tile in worlds[index]:
                continue
            opened_now = set()
            reachable = [tile]
            while reachable:
                i = reachable.pop()
                if i in opened_now or i in opened:
                    continue
                assert i not in worlds[index]
                opened_now.add(i)
                if not all_numbers[index][i]:
                    reachable.extend(j for j in cells if adjacent(i, j))
            key = tuple((i, all_numbers[index][i]) for i in sorted(opened_now))
            branches[key].append(index)
        return sum(value(tuple(indexes), opened | frozenset(i for i, _ in info))
                   for info, indexes in branches.items())

    @cache
    def value(belief, opened):
        if len(belief) == 1:
            return 1
        return max(action(belief, opened, tile) for tile in unknown if tile not in opened)

    return worlds, [action(tuple(range(len(worlds))), seen, tile) for tile in unknown]


def check(state, rows, cols, mine_count):
    near, hidden, flagged, worlds = enumerate_layouts(state, rows, cols, mine_count, 2000)
    if not hidden:
        return 0
    full_worlds, expected = reference(state, rows, cols, mine_count)
    assert set(full_worlds) == {world | flagged for world in worlds}, (state, full_worlds, worlds)
    tree = make_tree(near, hidden, flagged, worlds, 1000000)
    actual = tree.scores()
    assert actual == expected, (state, rows, cols, mine_count, actual, expected)
    assert tree.value(tree.root) == max(expected)
    for cell, mask in zip(hidden, tree.safe):
        assert mask.bit_count() == sum(cell not in world for world in full_worlds)
    return len(expected)


def main():
    fixture_cases = [
        ("H1H", 1, 3, 1),
        ("HHHHHHHHH", 3, 3, 1),
        ("0HHHHHHHH", 3, 3, 1),
        ("M1HHHHHHH", 3, 3, 2),
        ("H2HHHHHHH", 3, 3, 3),
    ]
    rng = random.Random(20261118)
    cases = list(fixture_cases)
    for rows, cols in ((2, 3), (2, 4), (3, 3), (3, 4)):
        cells = tuple(range(rows * cols))
        for _ in range(45):
            mine_count = rng.randint(1, 3)
            mines = set(rng.sample(cells, mine_count))
            safe = [i for i in cells if i not in mines]
            unhidden = set(rng.sample(safe, rng.randrange(min(len(safe), 5))))
            flags = set(rng.sample(sorted(mines), rng.randrange(min(mine_count, 2) + 1)))
            board = [
                "M" if i in flags else
                str(sum(max(abs(i // cols - j // cols), abs(i % cols - j % cols)) == 1 for j in mines))
                if i in unhidden else "H"
                for i in cells
            ]
            if "H" in board:
                cases.append(("".join(board), rows, cols, mine_count))
    count = sum(check(*case) for case in cases)
    print(f"Matched explicit flood-fill reference on {len(cases)} boards and {count} forced first clicks.")


if __name__ == "__main__":
    main()
