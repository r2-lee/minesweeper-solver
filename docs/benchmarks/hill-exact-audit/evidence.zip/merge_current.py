import argparse
import csv
import json
from pathlib import Path
import subprocess
import sys

patterns = ("smallest-python.jsonl", "below11000-python.jsonl", "small-branching-python.jsonl",
            "hill/primary-corrected-*.tsv", "hill/primary-resume-*.tsv",
            "native-oracle/native-primary-pass*.tsv", "bounded-primary-*.tsv",
            "root-primary-*.tsv")
files = sorted({str(f) for pattern in patterns for f in Path(".").glob(pattern) if f.stat().st_size > 0})
p = argparse.ArgumentParser()
p.add_argument("--output", default="progress")
args = p.parse_args()
subprocess.run([sys.executable, "merge_audit.py", "hill/study-primary.tsv", "primary-matrices",
                args.output + "-merged.tsv", args.output + "-summary.json", *files], check=True)
with open(args.output + "-merged.tsv", encoding="utf-8",newline="") as f:
    resolved = {r["id"] for r in csv.DictReader(f, delimiter="\t") if r["status"] == "exact"}
with open("hill/study-primary.tsv", encoding="utf-8-sig",newline="") as f:
    reader = csv.DictReader(f, delimiter="\t")
    with open(args.output + "-remaining.tsv", "w", encoding="utf-8",newline="") as target:
        out = csv.DictWriter(target, reader.fieldnames, delimiter="\t")
        out.writeheader()
        out.writerows(r for r in reader if r["id"] not in resolved)
print("Exact:", len(resolved))
