from __future__ import annotations

import argparse
from collections import Counter, defaultdict
from concurrent.futures import ProcessPoolExecutor
import csv
from itertools import combinations
import json
import math
from pathlib import Path
import sys
from time import perf_counter


ROWS, COLS, MINES = 16, 30, 99


class LimitExceeded(Exception):
    pass


def neighbours(rows, cols):
    return tuple(
        tuple(r * cols + c
              for r in range(max(0, row - 1), min(rows, row + 2))
              for c in range(max(0, col - 1), min(cols, col + 2))
              if (r, c) != (row, col))
        for row in range(rows)
        for col in range(cols)
    )


def enumerate_layouts(state, rows, cols, mines, limit):
    from minesweeper.solver.endgame import _component_configurations
    from minesweeper.solver.frontier import Constraint, _split_components

    near = neighbours(rows, cols)
    if len(state) != rows * cols or any(c not in "HM012345678" for c in state):
        raise ValueError("invalid board encoding")

    hidden = tuple(i for i, char in enumerate(state) if char == "H")
    flagged = frozenset(i for i, char in enumerate(state) if char == "M")
    mines_left = mines - len(flagged)
    if not 0 <= mines_left <= len(hidden):
        raise ValueError("invalid remaining mine count")

    constraints = {}
    for i, char in enumerate(state):
        if char.isdigit():
            cells = tuple(j for j in near[i] if state[j] == "H")
            required = int(char) - sum(j in flagged for j in near[i])
            if not 0 <= required <= len(cells):
                raise ValueError(f"invalid clue at {i}")
            if cells in constraints and constraints[cells] != required:
                raise ValueError(f"conflicting clue at {i}")
            if cells:
                constraints[cells] = required

    frontier = {cell for cells in constraints for cell in cells}
    blank = tuple(cell for cell in hidden if cell not in frontier)
    groups = []
    for cells, rules in _split_components(
        [Constraint(cells, required) for cells, required in constraints.items()]
    ):
        configs = _component_configurations(cells, rules, limit)
        if configs is None:
            raise LimitExceeded("frontier component enumeration limit")
        by_count = defaultdict(list)
        for config in configs:
            by_count[len(config)].append(tuple(config))
        groups.append(by_count)

    # Suffix counts avoid visiting Cartesian products that violate the global total.
    counts = [None] * (len(groups) + 1)
    counts[-1] = {k: math.comb(len(blank), k)
                  for k in range(min(mines_left, len(blank)) + 1)}
    for i in reversed(range(len(groups))):
        counts[i] = Counter()
        for used, configs in groups[i].items():
            for rest, ways in counts[i + 1].items():
                if used + rest <= mines_left:
                    counts[i][used + rest] += len(configs) * ways
    count = counts[0].get(mines_left, 0)
    if not count:
        raise ValueError("visible board has no consistent layout")
    if count > limit:
        raise LimitExceeded(f"layout limit: {count}")

    def expand(index, remaining, chosen):
        if index == len(groups):
            for remainder in combinations(blank, remaining):
                yield frozenset(chosen + remainder)
            return
        for used, configs in groups[index].items():
            if counts[index + 1].get(remaining - used, 0):
                for config in configs:
                    yield from expand(index + 1, remaining - used, chosen + config)

    layouts = list(expand(0, mines_left, ()))
    if len(layouts) != count or len(set(layouts)) != count:
        raise RuntimeError("layout enumeration disagrees with exact count")
    return near, hidden, flagged, layouts


class ExactTree:
    """Maximize the number of uniformly weighted mine layouts won."""

    def __init__(self, digits, observations, links, count, node_limit):
        self.observations = observations
        self.links = links
        self.digits = digits
        self.numeric = [tuple(int.from_bytes(buffer, "little") for buffer in column)
                        for column in digits]
        self.conflicts = {}
        self.views = tuple(bytes(
            next((digit for digit, buf in enumerate(column) if buf[i // 8] & (1 << (i % 8))), 9)
            for column in self.digits)
            for i in range(count))
        self.safe = tuple(sum(masks) for masks in observations)
        self.world_count = count
        self.root = (1 << count) - 1
        self.node_limit = node_limit
        self.nodes = 0
        self.memo = {}

    def branches(self, belief, cell):
        return [group for mask in self.observations[cell] if (group := belief & mask)]

    @staticmethod
    def cells(mask):
        while mask:
            cell = mask & -mask
            yield cell.bit_length() - 1
            mask ^= cell

    def fixed_count(self, component, belief, total, mine_masks):
        local = [belief & mine_masks[cell] for cell in self.cells(component)]
        first_moment = sum(mask.bit_count() for mask in local)
        if first_moment % total:
            return False
        second_moment = first_moment + 2 * sum((a & b).bit_count() for a, b in combinations(local, 2))
        return first_moment ** 2 == total * second_moment

    def factor(self, belief, active, total):
        # Every clue couples only its 8 neighbours, all within distance two.
        # Distinct physical components can only interact via the total mine count.
        remaining = active
        groups = []
        while remaining:
            frontier = remaining & -remaining
            component = frontier
            remaining ^= frontier
            while frontier:
                connected = 0
                for cell in self.cells(frontier):
                    connected |= self.links[cell]
                frontier = remaining & connected
                remaining ^= frontier
                component |= frontier
            groups.append(component)

        if len(groups) == 1:
            return None

        mine_masks = [self.root ^ safety for safety in self.safe]
        parts = []
        coupled = 0
        for group in groups:
            if self.fixed_count(group, belief, total, mine_masks):
                parts.append(group)
            else:
                coupled |= group
        if coupled:
            parts.append(coupled)
        if len(parts) == 1:
            return None

        representative = belief & -belief
        subproblems = []
        for part in parts:
            subproblem = belief
            for cell in self.cells(active ^ part):
                if self.safe[cell] & representative:
                    subproblem &= self.safe[cell]
                else:
                    subproblem &= mine_masks[cell]
            subproblems.append(subproblem)

        if math.prod(m.bit_count() for m in subproblems) != total:
            raise RuntimeError("independent components disagree with the layout count")
        return math.prod(self.value(m) for m in subproblems)

    def incompatible(self, index):
        cached = self.conflicts.get(index)
        if cached is not None:
            return cached
        remaining = self.root ^ (1 << index)
        for cell, digit in enumerate(self.views[index]):
            if digit != 9 and len(self.observations[cell]) >= 2:
                remaining &= self.root ^ (self.safe[cell] ^ self.numeric[cell][digit])
                if not remaining:
                    break
        self.conflicts[index] = remaining
        return remaining

    def upper_bound(self, belief):
        # Two layouts with identical clues at every cell safe in both cannot
        # both survive any policy. Each clique of these pairs yields at most one win.
        cliques = 0
        while belief:
            representative = belief & -belief
            belief ^= representative
            clique = belief & self.incompatible(representative.bit_length() - 1)
            while clique:
                next_world = clique & -clique
                belief ^= next_world
                clique = belief & clique & self.incompatible(next_world.bit_length() - 1)
            cliques += 1
        return cliques

    def value(self, belief):
        if belief & (belief - 1) == 0:
            return 1
        value = self.memo.get(belief)
        if value is not None:
            return value

        self.nodes += 1
        if self.nodes > self.node_limit:
            raise LimitExceeded("search node limit")

        total = belief.bit_count()
        actions = []
        active = 0
        for cell, safety in enumerate(self.safe):
            survivors = belief & safety
            alive = survivors.bit_count()
            if 0 < alive < total:
                active |= 1 << cell
            if alive <= 1:
                continue
            groups = self.branches(belief, cell)
            if len(groups) < 2:
                continue
            if alive == total:
                # A risk-free informative reveal can always precede the optimal policy.
                value = sum(self.value(group) for group in groups)
                self.memo[belief] = value
                return value
            actions.append((alive, len(groups), survivors, groups))

        if actions and active.bit_count() >= 4:
            value = self.factor(belief, active, total)
            if value is not None:
                self.memo[belief] = value
                return value

        # A click with one possible safe clue can be deferred. If every click
        # is of that kind, at most one distinct layout can survive a policy.
        best = 1
        upper_bound = self.upper_bound(belief) if actions and total <= 96 else total
        if upper_bound == 1:
            self.memo[belief] = 1
            return 1
        seen_supersets = []
        for alive, _, survivors, groups in sorted(actions, reverse=True):
            if alive <= best:
                break
            # A click can be played before any other that implies its safety.
            if any(survivors & other == survivors for other in seen_supersets):
                continue
            seen_supersets.append(survivors)
            subtotal = 0
            upper = alive
            for size, group in sorted(((group.bit_count(), group) for group in groups), reverse=True):
                won = self.value(group)
                subtotal += won
                upper -= size - won
                if upper <= best:
                    break
            else:
                best = subtotal
                if best == upper_bound:
                    break
        self.memo[belief] = best
        return best

    def scores(self):
        # In the surviving layouts the selected cell is safe, so the optimal
        # policy is free to learn the same clue regardless of when it opens it.
        return [self.value(mask) if mask else 0 for mask in self.safe]


def make_tree(near, hidden, flagged, layouts, node_limit):
    columns = {cell: i for i, cell in enumerate(hidden)}
    flagged_digits = [sum(tile in flagged for tile in near[cell]) for cell in hidden]
    adjacent_hidden = {cell: [columns[tile] for tile in near[cell] if tile in columns]
                       for cell in hidden}
    count = len(layouts)
    buffers = [[bytearray((count + 7) // 8) for _ in range(9)] for _ in hidden]
    for layout_index, mines in enumerate(layouts):
        digits = flagged_digits.copy()
        for mine in mines:
            for col in adjacent_hidden[mine]:
                digits[col] += 1
        offset, bit_index = divmod(layout_index, 8)
        bit = 1 << bit_index
        for col, cell in enumerate(hidden):
            if cell not in mines:
                buffers[col][digits[col]][offset] |= bit
    observations = [tuple(int.from_bytes(buffer, "little") for buffer in column if any(buffer))
                    for column in buffers]
    links = []
    for cell in hidden:
        local = set(near[cell])
        for neighbour in near[cell]:
            local.update(near[neighbour])
        links.append(sum(1 << columns[other] for other in local if other in columns and cell != other))
    return ExactTree(buffers, observations, links, count, node_limit)


def progress_scores(tree):
    result = []
    for cell in range(len(tree.safe)):
        progress = 0
        clears = 0
        two_step = 0
        for group in tree.branches(tree.root, cell):
            size = group.bit_count()
            candidates = [(other == tree.root, (group & other).bit_count())
                          for col, other in enumerate(tree.safe) if col != cell]
            next_safety = max((safe for _, safe in candidates), default=0)
            two_step += next_safety or size
            added = sum(safe == size and not initially_safe for initially_safe, safe in candidates)
            if added:
                progress += size
                clears += size * added
        result.append([progress, clears, two_step])
    return result


def read_states(path):
    with open(path, encoding="utf-8-sig", newline="") as stream:
        yield from csv.DictReader(stream, delimiter="\t")


def solve_one(task):
    row, project, layout_limit, node_limit = task
    if project not in sys.path:
        sys.path.insert(0, project)
    started = perf_counter()
    result = {"id": row["id"]}
    try:
        near, hidden, flagged, layouts = enumerate_layouts(row["state"], ROWS, COLS, MINES, layout_limit)
        count = len(layouts)
        if count != int(row["layout_count"]):
            raise ValueError(f"layout count mismatch: Hill {row['layout_count']} / exact {count}")
        tile = int(row["hill_tile"])
        if tile not in hidden:
            raise ValueError(f"Hill tile {tile} was not hidden")
        tree = make_tree(near, hidden, flagged, layouts, node_limit)
        safety = [mask.bit_count() for mask in tree.safe]
        if abs(safety[hidden.index(tile)] / count - float(row["hill_safety"])) > 1e-8:
            result["hill_safety_delta"] = safety[hidden.index(tile)] / count - float(row["hill_safety"])
        scores = tree.scores()
        optimal = max(scores)
        if tree.value(tree.root) != optimal:
            raise RuntimeError("root action values disagree with maximum")
        result.update(status="exact", layouts=count, nodes=tree.nodes,
                      tile_values=[[t, s, q] for t, s, q in zip(hidden, safety, scores)],
                      tile_features=progress_scores(tree))
    except LimitExceeded as err:
        result.update(status="budget", reason=str(err))
        if "tree" in locals():
            result["nodes"] = tree.nodes
    except ValueError as err:
        result.update(status="invalid", reason=str(err))
    result["seconds"] = round(perf_counter() - started, 6)
    return result


def main():
    parser = argparse.ArgumentParser(description="Solve captured visible Minesweeper boards exactly")
    parser.add_argument("project", help="path to PyStand-py38-pyqt5-lite for constraint enumeration")
    parser.add_argument("states", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--jobs", type=int, default=1)
    parser.add_argument("--layout-limit", type=int, default=50000)
    parser.add_argument("--node-limit", type=int, default=350000)
    args = parser.parse_args()
    tasks = [(row, str(Path(args.project).resolve()), args.layout_limit, args.node_limit)
             for row in read_states(args.states)]
    with args.output.open("w", encoding="utf-8") as stream:
        with ProcessPoolExecutor(max_workers=args.jobs) as pool:
            results = pool.map(solve_one, tasks, chunksize=1) if args.jobs > 1 else map(solve_one, tasks)
            counts = Counter()
            for result in results:
                counts[result["status"]] += 1
                stream.write(json.dumps(result) + "\n")
                stream.flush()
                if sum(counts.values()) % 20 == 0:
                    print(sum(counts.values()), len(tasks), dict(counts), flush=True)
    print(dict(counts), flush=True)


if __name__ == "__main__":
    main()
