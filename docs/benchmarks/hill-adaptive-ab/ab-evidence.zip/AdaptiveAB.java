import java.io.BufferedWriter;
import java.io.IOException;
import java.lang.reflect.Method;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import minesweeper.gamestate.GameStateModel;
import minesweeper.gamestate.GameStateReader;
import minesweeper.solver.Solver;
import minesweeper.solver.settings.PlayStyle;
import minesweeper.solver.settings.SettingsFactory;
import minesweeper.solver.settings.SettingsFactory.Setting;
import minesweeper.structure.Action;
import minesweeper.structure.Location;

public final class AdaptiveAB {
    private static final int ROWS = 16;
    private static final int COLS = 30;
    private static final int MINES = 99;
    private static final Location FIRST = new Location(3, 3);
    private static final String HEADER = "id\twon\twall_nanos\tguesses\ttrace\tscreened\ttriggered\tcompleted\tchanged\tenumeration_rejected\tadaptive_nanos\tdeep_nodes";

    private static Location location(int i) {
        return new Location(i % COLS, i / COLS);
    }

    private static GameStateModel setup(String layout) throws IOException {
        if (layout.length() != ROWS * COLS) {
            throw new IOException("wrong layout size");
        }
        List<Location> mines = new ArrayList<>(MINES);
        for (int i = 0; i < layout.length(); i++) {
            char cell = layout.charAt(i);
            if (cell == '1') {
                Location location = location(i);
                if (Math.abs(location.x - FIRST.x) <= 1 && Math.abs(location.y - FIRST.y) <= 1) {
                    throw new IOException("layout violates the zero opening");
                }
                mines.add(location);
            } else if (cell != '0') {
                throw new IOException("invalid layout character");
            }
        }
        if (mines.size() != MINES) {
            throw new IOException("wrong mine count");
        }
        GameStateModel game = GameStateReader.loadMines(COLS, ROWS, mines, List.of());
        if (!game.doAction(new Action(FIRST, Action.CLEAR)) || game.query(FIRST) != 0) {
            throw new IOException("opening failed");
        }
        return game;
    }

    private static String play(String line, Setting setting, Method statsMethod) throws Exception {
        long started = System.nanoTime();
        int tab = line.indexOf('\t');
        String id = line.substring(0, tab);
        String layout = line.substring(tab + 1);
        GameStateModel game = setup(layout);
        Solver solver = new Solver(game, SettingsFactory.GetSettings(setting).setSingleThread(true), false);
        solver.setPlayStyle(PlayStyle.NO_FLAG);
        int guesses = 0;
        StringBuilder trace = new StringBuilder();
        for (int step = 0; step < 1000 && game.getGameState() == GameStateModel.STARTED; step++) {
            solver.start();
            int changes = 0;
            for (Action action : solver.getResult()) {
                int tile = action.y * COLS + action.x;
                boolean mine = layout.charAt(tile) == '1';
                if (mine && action.getAction() == Action.CLEAR && action.isCertainty()) {
                    throw new IllegalStateException("false certainty on board " + id);
                }
                if (!mine && action.getAction() == Action.FLAG) {
                    throw new IllegalStateException("false flag on board " + id);
                }
                boolean changed = game.doAction(action);
                if (changed) {
                    changes++;
                    if (action.getAction() == Action.CLEAR && !action.isCertainty()) {
                        if (guesses++ > 0) {
                            trace.append(',');
                        }
                        trace.append(tile).append(':').append(action.getMoveMethod())
                             .append(':').append(action.getBigProb());
                    }
                }
                if (game.getGameState() != GameStateModel.STARTED) {
                    break;
                }
            }
            if (changes == 0) {
                throw new IllegalStateException("no progress on board " + id);
            }
        }
        if (game.getGameState() != GameStateModel.WON && game.getGameState() != GameStateModel.LOST) {
            throw new IllegalStateException("unfinished board " + id);
        }
        long elapsed = System.nanoTime() - started;
        long[] stats = statsMethod == null ? new long[7] : (long[]) statsMethod.invoke(solver);
        StringBuilder row = new StringBuilder(id);
        row.append('\t').append(game.getGameState() == GameStateModel.WON ? 1 : 0)
           .append('\t').append(elapsed).append('\t').append(guesses).append('\t').append(trace);
        for (long value : stats) {
            row.append('\t').append(value);
        }
        return row.toString();
    }

    private static void run(List<String> rows, Setting setting, Method stats, ExecutorService workers,
                            BufferedWriter output) throws Exception {
        List<Future<String>> results = new ArrayList<>(rows.size());
        for (String line : rows) {
            results.add(workers.submit(() -> play(line, setting, stats)));
        }
        int count = 0;
        for (Future<String> result : results) {
            String row = result.get();
            if (output != null) {
                output.write(row);
                output.newLine();
                if (++count % 500 == 0) {
                    output.flush();
                    System.err.println(setting + " " + count + "/" + rows.size());
                }
            }
        }
    }

    public static void main(String[] args) throws Exception {
        if (args.length != 7) {
            throw new IllegalArgumentException(
                "usage: AdaptiveAB <layouts> <baseline|adaptive> <workers> <results> <first> <count> <warmup>");
        }
        List<String> layouts = Files.readAllLines(Path.of(args[0]), StandardCharsets.US_ASCII);
        Setting setting = Setting.valueOf(args[1].equals("adaptive") ? "LARGE_ADAPTIVE_ANALYSIS" : "LARGE_ANALYSIS");
        Method stats = args[1].equals("adaptive") ? Solver.class.getMethod("getAdaptiveGuessStats") : null;
        int workerCount = Integer.parseInt(args[2]);
        int first = Integer.parseInt(args[4]);
        int count = Integer.parseInt(args[5]);
        int warmup = Integer.parseInt(args[6]);
        ExecutorService workers = Executors.newFixedThreadPool(workerCount);
        try {
            run(layouts.subList(0, warmup), setting, stats, workers, null);
            try (BufferedWriter output = Files.newBufferedWriter(Path.of(args[3]), StandardCharsets.US_ASCII)) {
                output.write(HEADER);
                output.newLine();
                long start = System.nanoTime();
                run(layouts.subList(first, first + count), setting, stats, workers, output);
                output.flush();
                System.out.printf(Locale.ROOT, "status=complete mode=%s games=%d workers=%d warmup=%d wall_nanos=%d%n",
                                  args[1], count, workerCount, warmup, System.nanoTime() - start);
            }
        } finally {
            workers.shutdownNow();
        }
    }
}
