import argparse
import csv
import json
import math
from pathlib import Path
import random


COLUMNS = ("screened", "triggered", "completed", "changed", "enumeration_rejected", "adaptive_nanos", "deep_nodes")


def read(path):
    with path.open(encoding="ascii", newline="") as file:
        rows = list(csv.DictReader(file, delimiter="\t"))
    data = {int(row["id"]): row for row in rows}
    if len(data) != len(rows):
        raise ValueError(f"duplicate board ID in {path}")
    return data


def timing(path, name, count):
    match = [line.split() for line in path.read_text(encoding="utf-8-sig").splitlines()
             if line.startswith("status=complete ")]
    if len(match) != 1:
        raise ValueError(f"missing completed timing: {path}")
    result = dict(field.split("=", 1) for field in match[0])
    if (result["mode"], int(result["games"])) != (name, count):
        raise ValueError(f"timing from wrong run: {path}")
    return result


def bootstrap_interval(only_adaptive, only_base, n):
    rng = random.Random(915799)
    p_positive = only_adaptive / n
    p_negative_conditional = only_base / (n - only_adaptive) if n > only_adaptive else 0
    draws = []
    for _ in range(100_000):
        positive = rng.binomialvariate(n, p_positive)
        negative = rng.binomialvariate(n - positive, p_negative_conditional)
        draws.append(positive - negative)
    draws.sort()
    return [draws[i] * 100 / n for i in (2499, 97499)]


def paired_metrics(ids, base, new):
    outcomes = {(0, 0): 0, (0, 1): 0, (1, 0): 0, (1, 1): 0}
    for i in ids:
        outcomes[int(base[i]["won"]), int(new[i]["won"])] += 1
    n = len(ids)
    only_base = outcomes[1, 0]
    only_new = outcomes[0, 1]
    return {
        "n": n, "baseline_wins": outcomes[1, 0] + outcomes[1, 1],
        "adaptive_wins": outcomes[0, 1] + outcomes[1, 1],
        "both_won": outcomes[1, 1], "both_lost": outcomes[0, 0],
        "only_baseline_won": only_base, "only_adaptive_won": only_new,
        "difference_pp": (only_new - only_base) * 100 / n,
        "paired_bootstrap_95_pp": bootstrap_interval(only_new, only_base, n),
    }


def main():
    parser = argparse.ArgumentParser(description="Summarize a paired Hill Java expert-board run")
    parser.add_argument("directory", type=Path)
    opts = parser.parse_args()
    base = read(opts.directory / "baseline.tsv")
    new = read(opts.directory / "adaptive.tsv")
    if len(base) != 10_000 or base.keys() != new.keys() or set(base) != set(range(10_000)):
        raise ValueError("the two arms must contain all 10,000 matching IDs")
    base_timing = timing(opts.directory / "baseline-timing.log", "baseline", len(base))
    new_timing = timing(opts.directory / "adaptive-timing.log", "adaptive", len(new))
    if any(base_timing[k] != new_timing[k] for k in ("workers", "warmup")):
        raise ValueError("the two arms used different run settings")

    for i, row in new.items():
        tested, triggered, completed, changed, rejected, spent, nodes = map(int, (row[col] for col in COLUMNS))
        if not (0 <= completed <= triggered <= tested and 0 <= changed <= triggered
                and nodes <= 1_300_000 * triggered):
            raise ValueError(f"invalid adaptive counters for board {i}")
        if changed == 0 and any(row[k] != base[i][k] for k in ("won", "guesses", "trace")):
            raise ValueError(f"the original action path diverged without an adaptive change on board {i}")

    aggregate = paired_metrics(sorted(base), base, new)
    original_wall = int(base_timing["wall_nanos"]) / 1e9
    variant_wall = int(new_timing["wall_nanos"]) / 1e9
    aggregate.update({
        "baseline_wall_seconds": original_wall, "adaptive_wall_seconds": variant_wall,
        "wall_difference_seconds": variant_wall - original_wall,
        "wall_relative_increase_pct": (variant_wall / original_wall - 1) * 100,
        "baseline_mean_game_ms": sum(int(row["wall_nanos"]) for row in base.values()) / (len(base) * 1e6),
        "adaptive_mean_game_ms": sum(int(row["wall_nanos"]) for row in new.values()) / (len(new) * 1e6),
        "workers": int(base_timing["workers"]), "warmup": int(base_timing["warmup"]),
        "adaptive_statistics": {key: sum(int(row[key]) for row in new.values()) for key in COLUMNS},
        "games_with_change": sum(int(row["changed"]) > 0 for row in new.values()),
        "games_with_trigger": sum(int(row["triggered"]) > 0 for row in new.values()),
        "seed_20261118": paired_metrics(range(5000), base, new),
        "seed_20261119": paired_metrics(range(5000, 10000), base, new),
    })
    (opts.directory / "ab-summary.json").write_text(json.dumps(aggregate, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(aggregate, indent=2))


if __name__ == "__main__":
    main()
