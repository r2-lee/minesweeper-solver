import minesweeper.gamestate.GameStateModel;
import minesweeper.gamestate.GameStateReader;
import minesweeper.solver.Solver;
import minesweeper.solver.settings.SettingsFactory;
import minesweeper.solver.settings.SettingsFactory.Setting;
import minesweeper.solver.settings.SolverSettings;
import minesweeper.structure.Location;
import java.util.Arrays;

public final class AdaptiveGuessIntegrationTest {
    private static void check(boolean condition, String message) {
        if (!condition) {
            throw new AssertionError(message);
        }
    }

    public static void main(String[] args) {
        SolverSettings baseline = SettingsFactory.GetSettings(Setting.LARGE_ANALYSIS).setSingleThread(true);
        SolverSettings adaptive = SettingsFactory.GetSettings(Setting.LARGE_ADAPTIVE_ANALYSIS).setSingleThread(true);
        check(!baseline.isAdaptiveGuess(), "the reference preset must stay unchanged");
        check(adaptive.isAdaptiveGuess(), "the new preset activates the gate");
        check(baseline.getBruteForceMaxSolutions() == adaptive.getBruteForceMaxSolutions(), "same layout threshold");
        check(baseline.getBruteForceVariableSolutions() == adaptive.getBruteForceVariableSolutions(), "same variable threshold");
        check(baseline.getBruteForceMaxNodes() == adaptive.getBruteForceMaxNodes(), "same default node cap");
        check(baseline.getBruteForceMaxIterations().equals(adaptive.getBruteForceMaxIterations()), "same default iteration cap");
        GameStateModel game = GameStateReader.loadMines(2, 2, Arrays.asList(new Location(0, 0)), Arrays.asList(new Location(1,1)));
        Solver solver = new Solver(game, adaptive, false);
        long[] stats = solver.getAdaptiveGuessStats();
        check(stats.length == 7, "statistics schema");
        stats[0] = 1;
        check(solver.getAdaptiveGuessStats()[0] == 0, "statistics snapshot must be defensive");
        System.out.println("Adaptive preset and statistics checks passed");
    }
}
