package minesweeper.solver;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import minesweeper.gamestate.GameStateModel;
import minesweeper.gamestate.GameStateReader;
import minesweeper.solver.settings.PlayStyle;
import minesweeper.solver.settings.SettingsFactory;
import minesweeper.solver.settings.SettingsFactory.Setting;
import minesweeper.structure.Action;
import minesweeper.structure.Location;

public final class AdaptiveGuessLayoutsTest {
    private static BoardState board(int width, int height, List<Location> actualMines, List<Location> shown,
                                    List<Location> confirmed, List<Location> untrustedFlags) {
        GameStateModel game = GameStateReader.loadMines(width, height, actualMines, shown);
        for (Location flag : untrustedFlags) {
            game.doAction(new Action(flag, Action.FLAG));
        }
        Solver owner = new Solver(game, SettingsFactory.GetSettings(Setting.LARGE_ANALYSIS).setSingleThread(true), false);
        owner.setPlayStyle(PlayStyle.NO_FLAG);
        BoardState board = new BoardState(owner);
        board.process();
        for (Location mine : confirmed) {
            board.setMineFound(mine);
        }
        return board;
    }

    private static Location t(int x, int y) {
        return new Location(x, y);
    }

    private static void check(boolean value, String description) {
        if (!value) {
            throw new AssertionError(description);
        }
    }

    private static Set<String> worlds(AdaptiveGuessLayouts result, int expected) {
        check(result != null, "the correct visible count should be accepted");
        check(result.cells.length == result.clues.length, "each unknown tile must have a clue row");
        Set<String> worlds = new HashSet<>();
        for (int i = 0; i < expected; i++) {
            StringBuilder world = new StringBuilder(result.cells.length);
            for (byte[] clues : result.clues) {
                check(clues.length == expected, "each clue row must use every world");
                int clue = clues[i];
                check(clue >= 0 && clue <= 9, "clues must be 0–8 or 9 for a mine");
                world.append(clue == 9 ? 'M' : (char) ('0' + clue));
            }
            check(worlds.add(world.toString()), "a consistent mine layout must appear only once");
        }
        return worlds;
    }

    private static void confirmedFlagIsDifferentFromPhysicalFlag() {
        List<Location> confirmed = Collections.singletonList(t(0, 0));
        List<Location> visible = Collections.singletonList(t(1, 0));
        List<Location> physical = Collections.singletonList(t(3, 0));
        BoardState first = board(4, 2, Arrays.asList(t(0, 0), t(3, 0)), visible, confirmed, physical);
        BoardState second = board(4, 2, Arrays.asList(t(0, 0), t(3, 1)), visible, confirmed, physical);
        AdaptiveGuessLayouts result = AdaptiveGuessLayouts.enumerate(first, 2);
        Set<String> expected = new HashSet<>(Arrays.asList("1M1111", "11111M"));
        check(worlds(result, 2).equals(expected), "the physical flag must be considered in both possible states");
        Location[] cells = {t(2, 0), t(3, 0), t(0, 1), t(1, 1), t(2, 1), t(3, 1)};
        check(Arrays.equals(result.cells, cells), "unknown cells must be row-major and exclude confirmed mines");
        AdaptiveGuessLayouts alternate = AdaptiveGuessLayouts.enumerate(second, 2);
        check(alternate != null && Arrays.deepEquals(result.clues, alternate.clues),
            "layout ordering must depend only on the observation");
        check(AdaptiveGuessLayouts.enumerate(first, 1) == null, "too-small expected count must be rejected");
        check(AdaptiveGuessLayouts.enumerate(first, 3) == null, "too-large expected count must be rejected");
        check(AdaptiveGuessLayouts.enumerate(first, 40001) == null, "count above the budget must be rejected");
    }

    private static void revealedZeroConstrainsUnknownNeighbors() {
        BoardState partial = board(5, 2, Collections.singletonList(t(4, 1)), Collections.singletonList(t(0, 0)),
            Collections.emptyList(), Collections.emptyList());
        AdaptiveGuessLayouts result = AdaptiveGuessLayouts.enumerate(partial, 6);
        Set<String> worlds = worlds(result, 6);
        for (String world : worlds) {
            check(world.charAt(0) != 'M' && world.charAt(4) != 'M' && world.charAt(5) != 'M',
                "an unrevealed neighbor of a zero must be clear in every layout");
        }
    }

    private static void auditMatrix(String id, String state, int expected, Path matrix) throws IOException {
        int width = 30;
        int height = 16;
        List<Location> visible = new ArrayList<>();
        List<Location> known = new ArrayList<>();
        List<Location> hidden = new ArrayList<>();
        for (int i = 0; i < state.length(); i++) {
            Location tile = t(i % width, i / width);
            char clue = state.charAt(i);
            if (clue == 'H') {
                hidden.add(tile);
            } else if (clue == 'M') {
                known.add(tile);
            } else {
                visible.add(tile);
            }
        }
        try (BufferedReader reader = Files.newBufferedReader(matrix)) {
            String[] dimensions = reader.readLine().split(" ");
            check(Integer.parseInt(dimensions[0]) == expected && Integer.parseInt(dimensions[1]) == hidden.size(),
                "matrix dimensions must agree with the audit row");
            List<Location> mines = new ArrayList<>(known);
            List<String> columns = new ArrayList<>();
            for (Location tile : hidden) {
                String column = reader.readLine();
                check(column != null && column.length() == expected, "each reference column must contain the same layouts");
                if (column.charAt(0) == 'M') {
                    mines.add(tile);
                }
                columns.add(column);
            }
            check(mines.size() == 99, "Expert layout must contain 99 mines");
            BoardState board = board(width, height, mines, visible, known, Collections.emptyList());
            AdaptiveGuessLayouts result = AdaptiveGuessLayouts.enumerate(board, expected);
            Set<String> actual = worlds(result, expected);
            check(Arrays.asList(result.cells).equals(hidden), "reference and result tile order differ for " + id);
            for (int i = 0; i < expected; i++) {
                StringBuilder world = new StringBuilder(columns.size());
                for (String column : columns) {
                    world.append(column.charAt(i));
                }
                check(actual.remove(world.toString()), "missing reference layout " + i + " for " + id);
            }
            check(actual.isEmpty(), "unexpected layouts for " + id);
        }
    }

    public static void main(String[] args) throws IOException {
        confirmedFlagIsDifferentFromPhysicalFlag();
        revealedZeroConstrainsUnknownNeighbors();
        int auditCount = 0;
        if (args.length >= 2) {
            Path folder = Paths.get(args[1]);
            List<String> requested = Arrays.asList(args).subList(2, args.length);
            try (BufferedReader reader = Files.newBufferedReader(Paths.get(args[0]))) {
                check(reader.readLine().startsWith("id\t"), "expected a headered audit TSV");
                for (String row = reader.readLine(); row != null; row = reader.readLine()) {
                    String[] fields = row.split("\t");
                    if (requested.isEmpty() || requested.contains(fields[0])) {
                        auditMatrix(fields[0], fields[4], Integer.parseInt(fields[8]), folder.resolve(fields[0] + ".txt"));
                        auditCount++;
                    }
                }
            }
            check(requested.isEmpty() ? auditCount > 0 : auditCount == requested.size(), "requested audit cases missing");
        }
        System.out.println("AdaptiveGuessLayoutsTest passed two visible-board cases and " + auditCount + " exact audit matrices");
    }
}
