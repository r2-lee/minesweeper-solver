"""Create and verify the paired Expert-board corpus before running either arm."""

from hashlib import sha256
import json
from pathlib import Path
import random
import sys


BENCH = Path(__file__).resolve().parent
BENCHMARK_ROOT = BENCH.parent.parent
ROWS, COLS, MINES = 16, 30, 99
FIRST_ROW, FIRST_COL = 3, 3
SEEDS = (20261118, 20261119)
BOARDS_PER_SEED = 5000
EXCLUDED = {
    row * COLS + col
    for row in range(FIRST_ROW - 1, FIRST_ROW + 2)
    for col in range(FIRST_COL - 1, FIRST_COL + 2)
}
AVAILABLE = tuple(tile for tile in range(ROWS * COLS) if tile not in EXCLUDED)
HISTORICAL = ("layouts-2026-0-5000.tsv", "layouts-9127-0-5000.tsv")


def require_valid(layout: bytes) -> None:
    if (
        len(layout) != ROWS * COLS
        or layout.count(b"1") != MINES
        or any(char not in b"01" for char in layout)
        or any(layout[tile] != ord("0") for tile in EXCLUDED)
    ):
        raise ValueError("Invalid Expert layout or nonzero first click")


def historical_layouts() -> tuple[set[bytes], dict[str, str]]:
    layouts = set()
    hashes = {}
    for name in HISTORICAL:
        raw = (BENCHMARK_ROOT / name).read_bytes()
        hashes[name] = sha256(raw).hexdigest()
        lines = raw.splitlines()
        if len(lines) != BOARDS_PER_SEED:
            raise ValueError(f"{name} has {len(lines)} layouts")
        for index, line in enumerate(lines):
            key, layout = line.split(b"\t")
            if int(key) != index:
                raise ValueError(f"{name} has an unexpected ID at {index}")
            require_valid(layout)
            layouts.add(layout)
    return layouts, hashes


def write_verified(path: Path, content: bytes) -> None:
    try:
        with path.open("xb") as stream:
            stream.write(content)
    except FileExistsError:
        if path.read_bytes() != content:
            raise ValueError(f"Existing file differs from the reproduced corpus: {path}")


def main() -> None:
    historical, old_hashes = historical_layouts()
    fresh = set()
    rows = []
    for seed in SEEDS:
        rng = random.Random(seed)
        for _ in range(BOARDS_PER_SEED):
            cells = bytearray(b"0" * (ROWS * COLS))
            for tile in rng.sample(AVAILABLE, MINES):
                cells[tile] = ord("1")
            layout = bytes(cells)
            require_valid(layout)
            if layout in historical or layout in fresh:
                raise ValueError(f"Duplicate layout for board ID {len(rows)}")
            fresh.add(layout)
            rows.append(str(len(rows)).encode("ascii") + b"\t" + layout + b"\n")

    corpus = b"".join(rows)
    digest = sha256(corpus).hexdigest()
    meta = {
        "board_count": len(rows),
        "rows": ROWS,
        "cols": COLS,
        "mines": MINES,
        "first_zero_based_xy": [FIRST_COL, FIRST_ROW],
        "excluded_indices": sorted(EXCLUDED),
        "seeds": list(SEEDS),
        "boards_per_seed": BOARDS_PER_SEED,
        "generator": "CPython random.Random(seed).sample(sorted_eligible_cells, 99)",
        "python": sys.version.split()[0],
        "sha256": digest,
        "historical_sha256": old_hashes,
        "overlap_with_historical": 0,
    }
    write_verified(BENCH / "fresh-expert.tsv", corpus)
    write_verified(BENCH / "corpus.json", (json.dumps(meta, indent=2) + "\n").encode("ascii"))
    print(f"Verified {len(fresh)} distinct new layouts; SHA256 {digest}", flush=True)


if __name__ == "__main__":
    main()
