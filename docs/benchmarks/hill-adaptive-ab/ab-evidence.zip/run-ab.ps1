param(
    [Parameter(Mandatory)][string] $Stock,
    [Parameter(Mandatory)][string] $Adaptive,
    [Parameter(Mandatory)][string] $Jdk,
    [Parameter(Mandatory)][string] $Output,
    [switch] $BuildOnly
)
$ErrorActionPreference = 'Stop'
$stockRoot = (Resolve-Path -LiteralPath $Stock).Path
$adaptiveRoot = (Resolve-Path -LiteralPath $Adaptive).Path
$jdkRoot = (Resolve-Path -LiteralPath $Jdk).Path
$work = (New-Item -ItemType Directory -Path $Output).FullName
$sourceNames = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'stock-sources.txt')
$adaptiveNames = @($sourceNames) + @(
    'MineSweeperSolver/src/minesweeper/solver/AdaptiveGuessLayouts.java',
    'MineSweeperSolver/src/minesweeper/solver/AdaptiveGuessSearch.java'
)
$stockClasses = (New-Item -ItemType Directory -Path (Join-Path $work 'stock-classes')).FullName
$adaptiveClasses = (New-Item -ItemType Directory -Path (Join-Path $work 'adaptive-classes')).FullName
$harnessClasses = (New-Item -ItemType Directory -Path (Join-Path $work 'harness-classes')).FullName

function Build-Solver($root, $names, $classes) {
    $sources = $names | ForEach-Object { '"' + (Join-Path $root $_).Replace('\','/') + '"' }
    $argFile = Join-Path $classes 'sources.txt'
    $sources | Set-Content -LiteralPath $argFile -Encoding utf8NoBOM
    & "$jdkRoot\bin\javac.exe" -encoding UTF-8 -d $classes "@$argFile"
    if ($LASTEXITCODE -ne 0) { throw "solver build failed at $root" }
}
Build-Solver $stockRoot $sourceNames $stockClasses
Build-Solver $adaptiveRoot $adaptiveNames $adaptiveClasses
& "$jdkRoot\bin\javac.exe" -cp $stockClasses -d $harnessClasses (Join-Path $PSScriptRoot 'AdaptiveAB.java')
if ($LASTEXITCODE -ne 0) { throw 'harness build failed' }

$corpus = Join-Path $PSScriptRoot 'fresh-expert.tsv'
$expected = (Get-Content -Raw -LiteralPath (Join-Path $PSScriptRoot 'corpus.json') | ConvertFrom-Json).sha256
if ((Get-FileHash -LiteralPath $corpus).Hash.ToLowerInvariant() -ne $expected) { throw 'layout checksum differs' }
if ($BuildOnly) { return }
foreach ($mode in @('baseline','adaptive')) {
    $classes = if($mode -eq 'baseline'){ $stockClasses } else { $adaptiveClasses }
    $results = Join-Path $work "$mode.tsv"
    & "$jdkRoot\bin\java.exe" '-Xms128m' '-Xmx2500m' '-XX:ActiveProcessorCount=8' -cp "$harnessClasses;$classes" AdaptiveAB $corpus $mode 8 $results 0 10000 192 2> (Join-Path $work "$mode-progress.log") |
        Tee-Object -FilePath (Join-Path $work "$mode-timing.log")
    if ($LASTEXITCODE -ne 0) { throw "$mode run failed" }
}
python (Join-Path $PSScriptRoot 'summarize_ab.py') $work
exit $LASTEXITCODE
